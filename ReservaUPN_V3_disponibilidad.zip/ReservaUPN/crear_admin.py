"""Asistente local para crear el PRIMER administrador sin contraseña fija."""
from getpass import getpass
from database import preparar_base_datos
from administradores import existen_administradores, crear_primer_administrador


def main():
    preparar_base_datos()
    if existen_administradores():
        print('Ya existe un administrador. Los demás se crean desde el panel del administrador principal.')
        return
    print('--- Configuración inicial: administrador principal de ReservaUPN ---')
    print('Esta operación se realiza solo la primera vez, desde esta computadora.')
    usuario = input('Usuario de administrador: ')
    nombres = input('Nombres: ')
    apellidos = input('Apellidos: ')
    correo = input('Correo: ')
    contrasena = getpass('Contraseña (mínimo 8 caracteres): ')
    confirmar = getpass('Repite la contraseña: ')
    if contrasena != confirmar:
        print('Las contraseñas no coinciden.')
        return
    bien, mensaje = crear_primer_administrador(usuario, nombres, apellidos, correo, contrasena)
    print(mensaje)


if __name__ == '__main__':
    main()
