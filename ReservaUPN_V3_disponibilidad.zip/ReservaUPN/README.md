# ReservaUPN — sistema de reservas (Python + SQLite + Tkinter)

Proyecto educativo de reservas para la Universidad Privada del Norte (UPN). Usa solo Python básico, SQLite y Tkinter; la única librería externa es OpenPyXL (para exportar a Excel).

## 1. Cómo ejecutarlo (Windows)

1. Instala **Python 3.10 o superior** desde python.org (marca «Add Python to PATH»).
2. Abre una terminal **dentro de la carpeta `ReservaUPN`** (donde está `menu.py`).
3. Instala la dependencia (una sola vez):

   ```bat
   python -m pip install -r requirements.txt
   ```

4. Abre el programa:

   ```bat
   python menu.py
   ```

   (También puedes usar doble clic en `INICIAR_ReservaUPN.bat`.)

5. **Primer uso:** como la base de datos aún no tiene administradores, en la pantalla de inicio aparece el enlace **«Primer uso: crear administrador principal»**. Complétalo una sola vez; luego el enlace desaparece. (Alternativa por terminal: `python crear_admin.py`.)

> Si en tu Windows se usa `py` en vez de `python`: `py -m pip install -r requirements.txt` y `py menu.py`.

## 2. Qué puede hacer cada persona

**Estudiante**
- **Registrarse** desde la pantalla de inicio: código, nombres, apellidos, correo UPN y contraseña.
  - Código: empieza con `N00` y tiene exactamente 9 caracteres (ej. `N00123456`).
  - Correo: lo escribe el estudiante y debe terminar en `@UPN.PE` (no se aceptan Gmail, Outlook, Hotmail ni otros). Se guarda en minúsculas.
  - No se permiten códigos ni correos repetidos.
- **Iniciar sesión con su correo UPN y contraseña** (no con el código).
- Ver sus datos, los recursos, hacer reservas, ver sus reservas, cancelarlas y cerrar sesión.

**Administrador**
- Iniciar sesión con su usuario y contraseña.
- Estudiantes: ver, crear y editar (incluye cambiar estado y contraseña).
- Inventario: agregar, editar, **desactivar** o **eliminar** recursos (computadoras, salas, libros, juegos o categorías nuevas). Eliminar solo funciona si el recurso nunca tuvo reservas; si las tuvo, se desactiva para no perder el historial.
- Categorías: agregar, editar y eliminar (solo si están vacías; Libros y Juegos están protegidas).
- Reservas: ver todas y cambiar su estado.
- Configuración: horario de atención, duraciones y días de préstamo de libros.
- Reportes: exportar a Excel (Reservas, Inventario y Estudiantes).
- **Administradores** (pestaña nueva): ver la lista, crear, editar y eliminar (con ventana de confirmación).

**Administrador principal:** es la primera cuenta creada. Es el único que puede crear y eliminar administradores, y no se puede desactivar. Para eliminarlo hay dos caminos desde la pestaña **Administradores**: pasar el rol a otro con **«Hacer principal»** (el nuevo principal ya puede eliminar al anterior), o, si es el único administrador, eliminarse a sí mismo (el programa vuelve al «Primer uso»). Un administrador común solo puede editar sus propios datos. Un estudiante nunca puede crear una cuenta de administrador.

## 3. Reservas
- Estados que bloquean el recurso: `Pendiente`, `Confirmada`, `En uso`. Los demás (`Finalizada`, `Cancelada`, `Rechazada`) lo liberan.
- Computadoras, salas y juegos se reservan por fecha y hora (1, 1.5 o 2 horas, de 09:00 a 21:00 por defecto).
- Los libros se prestan por 3 días (configurable).
- El sistema no deja que dos reservas del mismo recurso se crucen en fecha y horario.
- Todo se guarda en SQLite y no se pierde al cerrar el programa.

## 4. Archivos del proyecto

```text
ReservaUPN/
├── menu.py                 Inicio del programa (ejecuta este)
├── database.py             Conexión y estructura de SQLite
├── configuracion.py        Valores iniciales y estados
├── seguridad.py            Contraseñas con hash y sal (nunca en texto normal)
├── estudiantes.py          Registro, validaciones, inicio de sesión por correo
├── administradores.py      Inicio de sesión y gestión de administradores
├── recursos.py             Inventario y categorías
├── reservas.py             Reglas de reserva y cruces de horario
├── reportes.py             Exportación a Excel
├── interfaz.py             Inicio de sesión, registro y primer administrador
├── interfaz_estudiante.py  Panel del estudiante
├── interfaz_admin.py       Panel del administrador
├── interfaz_util.py        Tablas, botones y formularios reutilizables
├── crear_admin.py          Crear el administrador principal por terminal (opcional)
├── cargar_datos_ejemplo.py Recursos de demostración (opcional)
├── pruebas/test_sistema.py Pruebas automáticas (usan una copia temporal)
└── base_datos/reservaupn.db
```

**Base de datos (tablas):** `estudiantes`, `administradores`, `categorias`, `recursos`, `libros`, `juegos`, `reservas`, `historial`, `configuracion`. Los datos repetidos se evitan con campos únicos (código, correo, usuario, código de inventario, nombre de categoría).

## 5. ¿Dónde agrego información sin tocar el código?
- Estudiantes: registro en la pantalla de inicio o pestaña **Estudiantes**.
- Administradores: pestaña **Administradores**.
- Recursos y categorías: pestañas **Inventario** y **Categorías**.
- Horarios y préstamos: pestaña **Configuración**.

## 6. Probar el sistema

```bat
python -m unittest discover -s pruebas -v
```

Las pruebas trabajan sobre una copia temporal y no modifican `reservaupn.db`.

## 7. Para explicarlo en la exposición
`menu.py` prepara la base y abre `interfaz.py`. La persona se registra o inicia sesión (`estudiantes.py` / `administradores.py`). Las pantallas llaman a `recursos.py` y `reservas.py`, que guardan todo en SQLite mediante `database.py`. Cada archivo tiene una sola responsabilidad.

> Es un proyecto académico local: no se conecta a los sistemas reales de la UPN. No compartas una base de datos con datos de personas reales.
