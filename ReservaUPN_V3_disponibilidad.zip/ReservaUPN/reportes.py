"""Exportar un libro Excel con reservas, inventario y estudiantes."""
import os
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from reservas import consultar_todas_las_reservas
from recursos import listar_recursos
from estudiantes import listar_estudiantes
from database import CARPETA_PROYECTO


def preparar_hoja(hoja, encabezados, filas):
    hoja.append(encabezados)
    for fila in filas:
        # Evita que texto ingresado por un usuario se interprete como fórmula Excel.
        seguros = []
        for valor in fila:
            if isinstance(valor, str) and valor.lstrip().startswith(('=', '+', '-', '@')):
                valor = "'" + valor
            seguros.append(valor)
        hoja.append(seguros)
    cabecera = PatternFill('solid', fgColor='17365D')
    for celda in hoja[1]:
        celda.fill = cabecera
        celda.font = Font(name='Calibri', bold=True, color='FFFFFF')
        celda.alignment = Alignment(horizontal='center', vertical='center')
    hoja.row_dimensions[1].height = 28
    hoja.freeze_panes = 'A2'
    hoja.auto_filter.ref = hoja.dimensions
    for columna in hoja.columns:
        ancho = max(len(str(celda.value or '')) for celda in columna)
        hoja.column_dimensions[get_column_letter(columna[0].column)].width = min(42, max(14, ancho + 3))


def exportar_reporte_completo(ruta_archivo=None):
    if ruta_archivo is None:
        carpeta = os.path.join(CARPETA_PROYECTO, 'reportes')
        os.makedirs(carpeta, exist_ok=True)
        ruta_archivo = os.path.join(carpeta, 'ReservaUPN_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.xlsx')
    try:
        libro = Workbook()
        reservas = consultar_todas_las_reservas()
        hoja = libro.active
        hoja.title = 'Reservas'
        preparar_hoja(hoja,
            ['ID', 'Código estudiante', 'Estudiante', 'Código recurso', 'Recurso', 'Categoría',
             'Fecha inicio', 'Fecha fin', 'Hora inicio', 'Hora fin', 'Estado', 'Registrado'],
            [[r['id_reserva'], r['codigo_estudiante'], r['estudiante'], r['codigo_inventario'],
              r['recurso'], r['nombre_categoria'], r['fecha_inicio'], r['fecha_fin'],
              r['hora_inicio'], r['hora_fin'], r['estado'], r['fecha_registro']] for r in reservas])
        inventario = listar_recursos(incluir_inactivos=True)
        preparar_hoja(libro.create_sheet('Inventario'),
            ['Código', 'Nombre', 'Categoría', 'Descripción', 'Ubicación', 'Estado'],
            [[r['codigo_inventario'], r['nombre'], r['nombre_categoria'], r['descripcion'],
              r['ubicacion'], r['estado']] for r in inventario])
        estudiantes = listar_estudiantes()
        preparar_hoja(libro.create_sheet('Estudiantes'),
            ['Código', 'Nombres', 'Apellidos', 'Correo', 'Teléfono', 'Estado', 'Registrado'],
            [[e['codigo_estudiante'], e['nombres'], e['apellidos'], e['correo'], e['telefono'],
              e['estado'], e['fecha_registro']] for e in estudiantes])
        libro.save(ruta_archivo)
        return True, 'Reporte guardado en:\n' + ruta_archivo
    except (OSError, PermissionError, ValueError) as error:
        return False, 'No se pudo crear el Excel: ' + str(error)
