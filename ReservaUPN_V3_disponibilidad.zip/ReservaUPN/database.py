"""Una única conexión SQLite para todos los módulos.
La base incluida en el ZIP es una copia intacta de la recibida.
"""
import os
import sqlite3
from configuracion import CONFIGURACION_INICIAL, CATEGORIAS_INICIALES

CARPETA_PROYECTO = os.path.dirname(os.path.abspath(__file__))
RUTA_BASE_DATOS = os.path.join(CARPETA_PROYECTO, "base_datos", "reservaupn.db")


def conectar_base_datos():
    """Abrir SQLite con las llaves foráneas activadas."""
    os.makedirs(os.path.dirname(RUTA_BASE_DATOS), exist_ok=True)
    conexion = sqlite3.connect(RUTA_BASE_DATOS, timeout=10)
    conexion.row_factory = sqlite3.Row
    conexion.execute("PRAGMA foreign_keys = ON")
    conexion.execute("PRAGMA busy_timeout = 10000")
    return conexion


def preparar_base_datos():
    """Crear lo que falte sin borrar ni sustituir registros existentes."""
    conexion = conectar_base_datos()
    try:
        conexion.executescript("""
        CREATE TABLE IF NOT EXISTS estudiantes (
            codigo_estudiante TEXT PRIMARY KEY,
            nombres TEXT NOT NULL,
            apellidos TEXT NOT NULL,
            correo TEXT NOT NULL UNIQUE,
            telefono TEXT,
            contrasena_hash TEXT NOT NULL,
            estado TEXT NOT NULL DEFAULT 'Activo',
            fecha_registro TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS administradores (
            id_administrador INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario TEXT NOT NULL UNIQUE,
            nombres TEXT NOT NULL,
            apellidos TEXT NOT NULL,
            correo TEXT UNIQUE,
            telefono TEXT,
            contrasena_hash TEXT NOT NULL,
            estado TEXT NOT NULL DEFAULT 'Activo',
            es_principal INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS categorias (
            id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre_categoria TEXT NOT NULL UNIQUE,
            descripcion TEXT
        );
        CREATE TABLE IF NOT EXISTS recursos (
            id_recurso INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo_inventario TEXT NOT NULL UNIQUE,
            nombre TEXT NOT NULL,
            id_categoria INTEGER NOT NULL,
            descripcion TEXT,
            ubicacion TEXT,
            estado TEXT NOT NULL DEFAULT 'Disponible',
            FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
        );
        CREATE TABLE IF NOT EXISTS libros (
            id_recurso INTEGER PRIMARY KEY,
            autor TEXT,
            editorial TEXT,
            isbn TEXT,
            area TEXT,
            anio_publicacion INTEGER,
            FOREIGN KEY (id_recurso) REFERENCES recursos(id_recurso)
        );
        CREATE TABLE IF NOT EXISTS juegos (
            id_recurso INTEGER PRIMARY KEY,
            numero_jugadores INTEGER,
            descripcion_juego TEXT,
            FOREIGN KEY (id_recurso) REFERENCES recursos(id_recurso)
        );
        CREATE TABLE IF NOT EXISTS reservas (
            id_reserva INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo_estudiante TEXT NOT NULL,
            id_recurso INTEGER NOT NULL,
            fecha_inicio TEXT NOT NULL,
            fecha_fin TEXT NOT NULL,
            hora_inicio TEXT,
            hora_fin TEXT,
            estado TEXT NOT NULL DEFAULT 'Pendiente',
            fecha_registro TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (codigo_estudiante) REFERENCES estudiantes(codigo_estudiante),
            FOREIGN KEY (id_recurso) REFERENCES recursos(id_recurso),
            CHECK (fecha_fin >= fecha_inicio)
        );
        CREATE TABLE IF NOT EXISTS historial (
            id_historial INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo_estudiante TEXT,
            accion TEXT NOT NULL,
            descripcion TEXT,
            fecha_operacion TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (codigo_estudiante) REFERENCES estudiantes(codigo_estudiante)
        );
        CREATE TABLE IF NOT EXISTS configuracion (
            clave TEXT PRIMARY KEY,
            valor TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS indice_reservas_recurso
            ON reservas(id_recurso, fecha_inicio, fecha_fin);
        CREATE INDEX IF NOT EXISTS indice_reservas_estudiante
            ON reservas(codigo_estudiante);
        """)
        # Migración compatible con bases antiguas que carezcan de teléfono.
        for tabla in ("estudiantes", "administradores"):
            columnas = [fila[1] for fila in conexion.execute("PRAGMA table_info(" + tabla + ")")]
            if "telefono" not in columnas:
                conexion.execute("ALTER TABLE " + tabla + " ADD COLUMN telefono TEXT")
        # Administrador principal: solo él puede crear y eliminar otros administradores.
        columnas_admin = [fila[1] for fila in conexion.execute("PRAGMA table_info(administradores)")]
        if "es_principal" not in columnas_admin:
            conexion.execute("ALTER TABLE administradores ADD COLUMN es_principal INTEGER NOT NULL DEFAULT 0")
        # Si ya hay administradores pero ninguno es principal, el más antiguo pasa a serlo.
        if conexion.execute("SELECT 1 FROM administradores WHERE es_principal = 1").fetchone() is None:
            conexion.execute("""UPDATE administradores SET es_principal = 1
                WHERE id_administrador = (SELECT MIN(id_administrador) FROM administradores)""")
        for nombre, descripcion in CATEGORIAS_INICIALES:
            conexion.execute("INSERT OR IGNORE INTO categorias (nombre_categoria, descripcion) VALUES (?, ?)",
                             (nombre, descripcion))
        for clave, valor in CONFIGURACION_INICIAL.items():
            conexion.execute("INSERT OR IGNORE INTO configuracion (clave, valor) VALUES (?, ?)", (clave, valor))
        # Recordar el ID de Libros; así se puede renombrar la categoría
        # sin que se pierda la regla del préstamo por días.
        categoria_libros = conexion.execute("""SELECT r.id_categoria, COUNT(*) AS total
            FROM libros l JOIN recursos r ON r.id_recurso = l.id_recurso
            GROUP BY r.id_categoria ORDER BY total DESC LIMIT 1""").fetchone()
        if not categoria_libros:
            categoria_libros = conexion.execute("""SELECT id_categoria FROM categorias
                WHERE nombre_categoria = 'Libros' LIMIT 1""").fetchone()
        if categoria_libros:
            conexion.execute("INSERT OR IGNORE INTO configuracion (clave, valor) VALUES ('id_categoria_libros', ?)",
                             (str(categoria_libros[0]),))
        categoria_juegos = conexion.execute("""SELECT r.id_categoria, COUNT(*) AS total
            FROM juegos j JOIN recursos r ON r.id_recurso = j.id_recurso
            GROUP BY r.id_categoria ORDER BY total DESC LIMIT 1""").fetchone()
        if not categoria_juegos:
            categoria_juegos = conexion.execute("""SELECT id_categoria FROM categorias
                WHERE nombre_categoria = 'Juegos' LIMIT 1""").fetchone()
        if categoria_juegos:
            conexion.execute("INSERT OR IGNORE INTO configuracion (clave, valor) VALUES ('id_categoria_juegos', ?)",
                             (str(categoria_juegos[0]),))
        conexion.commit()
    finally:
        conexion.close()


def obtener_configuracion():
    conexion = conectar_base_datos()
    try:
        datos = dict(CONFIGURACION_INICIAL)
        for fila in conexion.execute("SELECT clave, valor FROM configuracion"):
            datos[fila["clave"]] = fila["valor"]
        return datos
    finally:
        conexion.close()


def actualizar_configuracion(apertura, cierre, duraciones, dias):
    """Guardar horarios en la tabla original sin cambiar su estructura."""
    from datetime import datetime
    try:
        hora_a = datetime.strptime(apertura.strip(), "%H:%M").time()
        hora_c = datetime.strptime(cierre.strip(), "%H:%M").time()
        if hora_a >= hora_c or apertura != hora_a.strftime('%H:%M') or cierre != hora_c.strftime('%H:%M'):
            return False, "Horario inválido. Usa HH:MM y apertura anterior al cierre."
        lista = [float(n.strip()) for n in duraciones.split(",")]
        if not lista or any(n <= 0 or n > 12 for n in lista):
            return False, "Ingresa duraciones válidas separadas por comas (ejemplo: 1,1.5,2)."
        if len(set(lista)) != len(lista):
            return False, "No repitas duraciones."
        plazo = int(dias)
        if plazo < 1 or plazo > 30:
            return False, "El préstamo debe durar entre 1 y 30 días."
        if min(lista) * 60 > (hora_c.hour * 60 + hora_c.minute) - (hora_a.hour * 60 + hora_a.minute):
            return False, "El horario de atención es demasiado corto."
    except (ValueError, TypeError):
        return False, "Revisa el formato de horarios, duraciones y días."
    conexion = conectar_base_datos()
    try:
        valores = {
            "hora_apertura": apertura,
            "hora_cierre": cierre,
            "duraciones_permitidas": ",".join(str(int(n)) if n.is_integer() else str(n) for n in lista),
            "duracion_maxima_reserva_horas": str(max(lista)),
            "duracion_prestamo_libros_dias": str(plazo),
        }
        for clave, valor in valores.items():
            conexion.execute("INSERT OR REPLACE INTO configuracion (clave, valor) VALUES (?, ?)", (clave, valor))
        conexion.commit()
        return True, "Configuración guardada correctamente."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al guardar: {error}"
    finally:
        conexion.close()
