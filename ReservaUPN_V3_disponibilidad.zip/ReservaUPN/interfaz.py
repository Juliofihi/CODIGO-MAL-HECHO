"""Pantalla inicial: iniciar sesión, registrarse como estudiante y entrar como administrador."""
import tkinter as tk
from tkinter import ttk, messagebox
from estudiantes import iniciar_sesion, registrar_estudiante
from administradores import iniciar_sesion_admin, existen_administradores, crear_primer_administrador
from interfaz_estudiante import PanelEstudiante
from interfaz_admin import PanelAdministrador
from interfaz_util import AZUL, FONDO, crear_dialogo, campo_texto, boton


class Aplicacion(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('ReservaUPN | Reservas universitarias')
        self.geometry('1100x720')
        self.minsize(860, 560)
        self.configure(bg=FONDO)
        self.estilos()
        self.mostrar_login()

    def estilos(self):
        estilos = ttk.Style(self)
        estilos.theme_use('clam')
        estilos.configure('TFrame', background=FONDO)
        estilos.configure('TLabel', background=FONDO, font=('Segoe UI', 10))
        estilos.configure('TNotebook', background=FONDO)
        estilos.configure('TNotebook.Tab', padding=(16, 10), font=('Segoe UI', 10))
        estilos.configure('TButton', font=('Segoe UI', 10), padding=7)
        estilos.configure('Treeview', rowheight=27, font=('Segoe UI', 10))
        estilos.configure('Treeview.Heading', font=('Segoe UI', 10, 'bold'))

    def limpiar(self):
        for elemento in self.winfo_children():
            elemento.destroy()

    def mostrar_login(self):
        self.limpiar()
        marco = tk.Frame(self, bg='white', padx=44, pady=30)
        marco.place(relx=0.5, rely=0.5, anchor='center')
        tk.Label(marco, text='ReservaUPN', font=('Segoe UI', 27, 'bold'),
                 fg=AZUL, bg='white').pack(pady=(0, 5))
        tk.Label(marco, text='Sistema universitario de reservas', font=('Segoe UI', 11),
                 bg='white', fg='#52667A').pack(pady=(0, 18))
        tk.Label(marco, text='Tipo de acceso', bg='white', anchor='w').pack(fill='x')
        tipo = ttk.Combobox(marco, state='readonly', width=35, values=['Estudiante', 'Administrador'])
        tipo.set('Estudiante')
        tipo.pack(fill='x', pady=(5, 12))
        etiqueta_usuario = tk.Label(marco, text='Correo institucional UPN', bg='white', anchor='w')
        etiqueta_usuario.pack(fill='x')
        usuario = ttk.Entry(marco, width=38, font=('Segoe UI', 11))
        usuario.pack(fill='x', ipady=6, pady=(5, 12))
        tk.Label(marco, text='Contraseña', bg='white', anchor='w').pack(fill='x')
        clave = ttk.Entry(marco, width=38, show='*', font=('Segoe UI', 11))
        clave.pack(fill='x', ipady=6, pady=(5, 12))

        def cambiar_tipo(evento=None):
            if tipo.get() == 'Estudiante':
                etiqueta_usuario.configure(text='Correo institucional UPN')
            else:
                etiqueta_usuario.configure(text='Usuario de administrador')
        tipo.bind('<<ComboboxSelected>>', cambiar_tipo)

        def entrar():
            if not usuario.get().strip() or not clave.get():
                messagebox.showwarning('Faltan datos', 'Ingresa tu correo (o usuario) y la contraseña.')
                return
            try:
                if tipo.get() == 'Estudiante':
                    datos = iniciar_sesion(usuario.get(), clave.get())
                    if datos:
                        self.mostrar_panel(PanelEstudiante, datos)
                    else:
                        messagebox.showerror('Acceso denegado', 'Correo, contraseña o estado incorrecto.')
                else:
                    datos = iniciar_sesion_admin(usuario.get(), clave.get())
                    if datos:
                        self.mostrar_panel(PanelAdministrador, datos)
                    else:
                        messagebox.showerror('Acceso denegado', 'Usuario, contraseña o estado incorrecto.')
            except Exception as error:
                messagebox.showerror('Error al ingresar', str(error))

        tk.Button(marco, text='INICIAR SESIÓN', command=entrar, bg=AZUL,
                  fg='white', font=('Segoe UI', 11, 'bold'), relief='flat',
                  cursor='hand2', padx=30, pady=10).pack(fill='x', pady=8)
        clave.bind('<Return>', lambda evento: entrar())
        tk.Button(marco, text='Registrarme como estudiante', command=self.ventana_registro,
                  bg='white', fg=AZUL, font=('Segoe UI', 10, 'underline'), relief='flat',
                  cursor='hand2').pack(pady=(8, 0))
        # Solo aparece mientras no exista ningún administrador (primer uso).
        if not existen_administradores():
            tk.Button(marco, text='Primer uso: crear administrador principal',
                      command=self.ventana_primer_admin, bg='white', fg='#9B5D22',
                      font=('Segoe UI', 10, 'underline'), relief='flat', cursor='hand2').pack(pady=(8, 0))

    # --- Registro de estudiantes ---
    def ventana_registro(self):
        dialogo, marco = crear_dialogo(self, 'Registro de estudiante')
        codigo = campo_texto(marco, 'Código de estudiante', '', 0)
        nombres = campo_texto(marco, 'Nombres', '', 1)
        apellidos = campo_texto(marco, 'Apellidos', '', 2)
        correo = campo_texto(marco, 'Correo institucional UPN', '', 3)
        clave = campo_texto(marco, 'Contraseña (8+ caracteres)', '', 4, secreto=True)
        repetir = campo_texto(marco, 'Repetir contraseña', '', 5, secreto=True)
        ttk.Label(marco, text='El código empieza con N00 y tiene 9 caracteres (ejemplo: N00123456).\n'
                              'El correo debe terminar en @UPN.PE.', foreground='#51687E'
                  ).grid(row=6, column=0, columnspan=2, pady=8)

        def guardar():
            if clave.get() != repetir.get():
                messagebox.showwarning('Revisar datos', 'Las contraseñas no coinciden.', parent=dialogo)
                return
            bien, mensaje = registrar_estudiante(codigo.get(), nombres.get(), apellidos.get(),
                                                 correo.get(), '', clave.get())
            if bien:
                dialogo.destroy()
                messagebox.showinfo('Registro', mensaje + '\nYa puedes iniciar sesión con tu correo UPN.')
            else:
                messagebox.showwarning('Revisar datos', mensaje, parent=dialogo)
        boton(marco, 'Registrarme', guardar).grid(row=7, column=1, sticky='e', pady=12)

    # --- Primer administrador (principal) ---
    def ventana_primer_admin(self):
        dialogo, marco = crear_dialogo(self, 'Crear administrador principal')
        usuario = campo_texto(marco, 'Usuario', '', 0)
        nombres = campo_texto(marco, 'Nombres', '', 1)
        apellidos = campo_texto(marco, 'Apellidos', '', 2)
        correo = campo_texto(marco, 'Correo', '', 3)
        clave = campo_texto(marco, 'Contraseña (8+ caracteres)', '', 4, secreto=True)
        repetir = campo_texto(marco, 'Repetir contraseña', '', 5, secreto=True)
        ttk.Label(marco, text='Esta cuenta podrá crear y eliminar a los demás administradores.',
                  foreground='#51687E').grid(row=6, column=0, columnspan=2, pady=8)

        def guardar():
            if clave.get() != repetir.get():
                messagebox.showwarning('Revisar datos', 'Las contraseñas no coinciden.', parent=dialogo)
                return
            bien, mensaje = crear_primer_administrador(usuario.get(), nombres.get(), apellidos.get(),
                                                       correo.get(), clave.get())
            if bien:
                dialogo.destroy()
                messagebox.showinfo('Administrador', mensaje)
                self.mostrar_login()
            else:
                messagebox.showwarning('Revisar datos', mensaje, parent=dialogo)
        boton(marco, 'Crear administrador', guardar).grid(row=7, column=1, sticky='e', pady=12)

    def mostrar_panel(self, tipo_panel, datos):
        self.limpiar()
        panel = tipo_panel(self, datos, self.mostrar_login)
        panel.pack(fill='both', expand=True)


def iniciar_interfaz():
    aplicacion = Aplicacion()
    aplicacion.mainloop()
