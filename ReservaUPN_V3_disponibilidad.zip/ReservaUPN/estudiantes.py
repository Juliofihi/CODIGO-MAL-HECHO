"""Funciones del estudiante: registro, inicio de sesión con correo UPN y mantenimiento."""
import sqlite3
from database import conectar_base_datos
from seguridad import crear_hash, verificar_contrasena, validar_contrasena
from configuracion import ESTADOS_ESTUDIANTE

DOMINIO_UPN = "@upn.pe"


def validar_codigo(codigo):
    """El código debe comenzar con N00 y tener exactamente 9 caracteres."""
    codigo = codigo.strip().upper()
    if len(codigo) != 9 or not codigo.startswith("N00"):
        return False, "El código debe comenzar con N00 y tener exactamente 9 caracteres (ejemplo: N00123456)."
    if not (codigo.isascii() and codigo.isalnum()):
        return False, "El código solo puede tener letras y números."
    return True, ""


def validar_correo_upn(correo):
    """Solo se aceptan correos institucionales que terminen en @UPN.PE."""
    correo = correo.strip().lower()
    if correo.count("@") != 1 or " " in correo:
        return False, "Escribe tu correo institucional completo (ejemplo: n00123456@upn.pe)."
    usuario = correo.split("@")[0]
    if usuario == "" or not correo.endswith(DOMINIO_UPN):
        return False, "Solo se aceptan correos institucionales que terminen en @UPN.PE (no Gmail, Outlook ni Hotmail)."
    return True, ""


def validar_datos(codigo, nombres, apellidos, correo, estado):
    valido, mensaje = validar_codigo(codigo)
    if not valido:
        return False, mensaje
    if not nombres.strip() or not apellidos.strip():
        return False, "Completa nombres y apellidos."
    valido, mensaje = validar_correo_upn(correo)
    if not valido:
        return False, mensaje
    if estado not in ESTADOS_ESTUDIANTE:
        return False, "Estado de estudiante no válido."
    return True, ""


def obtener_estudiante(codigo):
    conexion = conectar_base_datos()
    try:
        fila = conexion.execute("""SELECT codigo_estudiante, nombres, apellidos, correo, telefono,
                                      estado, fecha_registro FROM estudiantes
                                      WHERE codigo_estudiante = ?""", (codigo.strip().upper(),)).fetchone()
        return dict(fila) if fila else None
    finally:
        conexion.close()


def listar_estudiantes():
    conexion = conectar_base_datos()
    try:
        return [dict(fila) for fila in conexion.execute("""SELECT codigo_estudiante, nombres, apellidos, correo,
                telefono, estado, fecha_registro FROM estudiantes ORDER BY apellidos, nombres""")]
    finally:
        conexion.close()


def iniciar_sesion(correo, contrasena):
    """El estudiante entra con su correo UPN y contraseña (no con su código)."""
    if not correo or not contrasena:
        return None
    conexion = conectar_base_datos()
    try:
        fila = conexion.execute("""SELECT codigo_estudiante, contrasena_hash FROM estudiantes
                                  WHERE correo = ? AND estado = 'Activo'""",
                                (correo.strip().lower(),)).fetchone()
        if not fila or not verificar_contrasena(contrasena, fila['contrasena_hash']):
            return None
        codigo = fila['codigo_estudiante']
    finally:
        conexion.close()
    return obtener_estudiante(codigo)


def registrar_estudiante(codigo, nombres, apellidos, correo, telefono, contrasena):
    codigo, nombres, apellidos = codigo.strip().upper(), nombres.strip(), apellidos.strip()
    correo, telefono = correo.strip().lower(), telefono.strip()
    valido, mensaje = validar_datos(codigo, nombres, apellidos, correo, 'Activo')
    if not valido:
        return False, mensaje
    valido, mensaje = validar_contrasena(contrasena)
    if not valido:
        return False, mensaje
    conexion = conectar_base_datos()
    try:
        conexion.execute("""INSERT INTO estudiantes (codigo_estudiante, nombres, apellidos, correo,
                           telefono, contrasena_hash, estado) VALUES (?, ?, ?, ?, ?, ?, 'Activo')""",
                         (codigo, nombres, apellidos, correo, telefono, crear_hash(contrasena)))
        conexion.commit()
        return True, "Estudiante registrado correctamente."
    except sqlite3.IntegrityError:
        conexion.rollback()
        return False, "El código o el correo ya están registrados."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al registrar estudiante: {error}"
    finally:
        conexion.close()


def modificar_estudiante(codigo, nombres, apellidos, correo, telefono, estado, nueva_contrasena=''):
    codigo, nombres, apellidos = codigo.strip().upper(), nombres.strip(), apellidos.strip()
    correo, telefono = correo.strip().lower(), telefono.strip()
    valido, mensaje = validar_datos(codigo, nombres, apellidos, correo, estado)
    if not valido:
        return False, mensaje
    if nueva_contrasena:
        valido, mensaje = validar_contrasena(nueva_contrasena)
        if not valido:
            return False, mensaje
    conexion = conectar_base_datos()
    try:
        cursor = conexion.execute("""UPDATE estudiantes SET nombres = ?, apellidos = ?, correo = ?,
                   telefono = ?, estado = ? WHERE codigo_estudiante = ?""",
                                  (nombres, apellidos, correo, telefono, estado, codigo))
        if cursor.rowcount == 0:
            conexion.rollback()
            return False, "No se encontró el estudiante."
        if nueva_contrasena:
            conexion.execute("UPDATE estudiantes SET contrasena_hash = ? WHERE codigo_estudiante = ?",
                             (crear_hash(nueva_contrasena), codigo))
        conexion.commit()
        return True, "Datos del estudiante actualizados."
    except sqlite3.IntegrityError:
        conexion.rollback()
        return False, "El correo ya está asignado a otra cuenta."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al actualizar estudiante: {error}"
    finally:
        conexion.close()
