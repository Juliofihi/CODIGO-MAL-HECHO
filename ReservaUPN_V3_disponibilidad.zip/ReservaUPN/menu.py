"""Punto de inicio del sistema: ejecutar 'python menu.py'."""
from database import preparar_base_datos
from interfaz import iniciar_interfaz


if __name__ == '__main__':
    preparar_base_datos()
    iniciar_interfaz()
