"""Reservas con validaciones y transacción SQLite para evitar solapamientos."""
import sqlite3
from datetime import datetime, date, timedelta
from database import conectar_base_datos, obtener_configuracion
from configuracion import ESTADOS_RESERVA, ESTADOS_QUE_NO_BLOQUEAN


CONSULTA_RESERVAS = """SELECT r.id_reserva, r.codigo_estudiante,
    e.nombres || ' ' || e.apellidos AS estudiante,
    re.codigo_inventario, re.nombre AS recurso, c.nombre_categoria,
    r.fecha_inicio, r.fecha_fin, r.hora_inicio, r.hora_fin,
    r.estado, r.fecha_registro
    FROM reservas r
    JOIN estudiantes e ON e.codigo_estudiante = r.codigo_estudiante
    JOIN recursos re ON re.id_recurso = r.id_recurso
    JOIN categorias c ON c.id_categoria = re.id_categoria"""


def estados_inactivos_sql():
    return ','.join('?' for _ in ESTADOS_QUE_NO_BLOQUEAN)


def configuracion_reservas():
    config = obtener_configuracion()
    try:
        apertura = datetime.strptime(config['hora_apertura'], '%H:%M').time()
        cierre = datetime.strptime(config['hora_cierre'], '%H:%M').time()
        duraciones = [float(valor.strip()) for valor in config['duraciones_permitidas'].split(',')]
        dias = int(config['duracion_prestamo_libros_dias'])
        if not duraciones or dias < 1 or apertura >= cierre:
            raise ValueError('Configuración inválida')
        return apertura, cierre, duraciones, dias
    except (KeyError, ValueError):
        raise ValueError('La configuración de reservas está mal definida. Revisa el panel administrador.')


def buscar_solapamiento(conexion, id_recurso, fecha_inicio, fecha_fin,
                         hora_inicio=None, hora_fin=None, excluir_id=None):
    """Fechas y horas funcionan como intervalos [inicio, fin)."""
    sql = """SELECT id_reserva FROM reservas
        WHERE id_recurso = ? AND COALESCE(estado, 'Pendiente') NOT IN (""" + estados_inactivos_sql() + ")"
    parametros = [id_recurso] + ESTADOS_QUE_NO_BLOQUEAN[:]
    if excluir_id is not None:
        sql += " AND id_reserva <> ?"
        parametros.append(excluir_id)
    if hora_inicio is None:
        sql += " AND fecha_inicio < ? AND fecha_fin > ?"
        parametros.extend([fecha_fin, fecha_inicio])
    else:
        sql += " AND fecha_inicio = ? AND hora_inicio < ? AND hora_fin > ?"
        parametros.extend([fecha_inicio, hora_fin, hora_inicio])
    return conexion.execute(sql, parametros).fetchone() is not None


def crear_reserva(codigo_estudiante, codigo_recurso, fecha_inicio, hora_inicio=None, duracion_horas=None):
    """Retorna (éxito, mensaje). No crear reservas fuera de la interfaz es posible."""
    codigo_estudiante = str(codigo_estudiante).strip().upper()
    codigo_recurso = str(codigo_recurso).strip().upper()
    try:
        dia = date.fromisoformat(fecha_inicio)
        if dia.isoformat() != fecha_inicio:
            raise ValueError()
    except (ValueError, TypeError):
        return False, 'La fecha debe escribirse AAAA-MM-DD.'
    if dia < date.today():
        return False, 'No puedes reservar en una fecha pasada.'

    try:
        apertura, cierre, duraciones, dias = configuracion_reservas()
    except ValueError as error:
        return False, str(error)
    conexion = conectar_base_datos()
    try:
        # Impide que dos procesos comprueben disponibilidad a la vez.
        conexion.execute('BEGIN IMMEDIATE')
        estudiante = conexion.execute("""SELECT codigo_estudiante FROM estudiantes
            WHERE codigo_estudiante = ? AND estado = 'Activo'""", (codigo_estudiante,)).fetchone()
        if not estudiante:
            return False, 'El estudiante no existe o se encuentra inactivo.'
        recurso = conexion.execute("""SELECT re.id_recurso, re.nombre, re.estado, re.id_categoria, c.nombre_categoria
            FROM recursos re JOIN categorias c ON re.id_categoria = c.id_categoria
            WHERE re.codigo_inventario = ?""", (codigo_recurso,)).fetchone()
        if not recurso:
            return False, 'No se encontró el recurso.'
        if recurso['estado'] != 'Disponible':
            return False, 'El recurso no se encuentra disponible.'
        id_recurso = recurso['id_recurso']
        fila_libros = conexion.execute("SELECT valor FROM configuracion WHERE clave = 'id_categoria_libros'").fetchone()
        id_categoria_libros = int(fila_libros['valor']) if fila_libros else -1
        if recurso['id_categoria'] == id_categoria_libros:
            fin_dia = dia + timedelta(days=dias)
            fecha_fin = fin_dia.isoformat()
            comienzo, fin = None, None
            if buscar_solapamiento(conexion, id_recurso, fecha_inicio, fecha_fin):
                return False, 'Este libro está prestado durante esas fechas.'
        else:
            try:
                duracion = float(duracion_horas)
            except (ValueError, TypeError):
                return False, 'Selecciona una duración de reserva.'
            if duracion not in duraciones:
                return False, 'Duración no permitida. Revisa las opciones de reserva.'
            try:
                instante = datetime.strptime(hora_inicio, '%H:%M')
                if instante.strftime('%H:%M') != hora_inicio:
                    raise ValueError()
            except (ValueError, TypeError):
                return False, 'La hora debe escribirse HH:MM (por ejemplo, 10:30).'
            fin_instante = instante + timedelta(minutes=round(duracion * 60))
            if instante.time() < apertura or fin_instante.date() != instante.date() or fin_instante.time() > cierre:
                return False, f'La reserva debe estar dentro del horario {apertura:%H:%M} a {cierre:%H:%M}.'
            if dia == date.today() and instante.time() <= datetime.now().time():
                return False, 'La hora de inicio debe ser futura.'
            comienzo, fin = instante.strftime('%H:%M'), fin_instante.strftime('%H:%M')
            fecha_fin = fecha_inicio
            if buscar_solapamiento(conexion, id_recurso, fecha_inicio, fecha_fin, comienzo, fin):
                return False, 'Ya existe otra reserva para ese recurso en el horario elegido.'

        cursor = conexion.execute("""INSERT INTO reservas
            (codigo_estudiante, id_recurso, fecha_inicio, fecha_fin, hora_inicio, hora_fin, estado)
            VALUES (?, ?, ?, ?, ?, ?, 'Pendiente')""",
            (codigo_estudiante, id_recurso, fecha_inicio, fecha_fin, comienzo, fin))
        id_reserva = cursor.lastrowid
        conexion.execute("""INSERT INTO historial (codigo_estudiante, accion, descripcion)
            VALUES (?, ?, ?)""", (codigo_estudiante, 'Reserva creada',
                                    f'Reserva {id_reserva}: {recurso["nombre"]}'))
        conexion.commit()
        return True, f'Reserva N.° {id_reserva} registrada correctamente.'
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f'Error de base de datos: {error}'
    finally:
        conexion.close()


def horarios_ocupados(codigo_recurso, fecha):
    """Devuelve la lista de horarios ya reservados de un recurso en una fecha (AAAA-MM-DD).
    Retorna None si la fecha está mal escrita."""
    try:
        date.fromisoformat(fecha)
    except (ValueError, TypeError):
        return None
    conexion = conectar_base_datos()
    try:
        recurso = conexion.execute("SELECT id_recurso FROM recursos WHERE codigo_inventario = ?",
                                   (str(codigo_recurso).strip().upper(),)).fetchone()
        if not recurso:
            return []
        filas = conexion.execute("""SELECT hora_inicio, hora_fin, fecha_fin FROM reservas
            WHERE id_recurso = ? AND COALESCE(estado, 'Pendiente') NOT IN (""" + estados_inactivos_sql() + """)
            AND ((hora_inicio IS NOT NULL AND fecha_inicio = ?)
                 OR (hora_inicio IS NULL AND fecha_inicio <= ? AND fecha_fin > ?))
            ORDER BY hora_inicio""", [recurso['id_recurso']] + ESTADOS_QUE_NO_BLOQUEAN + [fecha, fecha, fecha]).fetchall()
        return [(f['hora_inicio'] + ' a ' + f['hora_fin']) if f['hora_inicio'] else ('Prestado hasta ' + f['fecha_fin'])
                for f in filas]
    finally:
        conexion.close()


def consultar_reservas_estudiante(codigo_estudiante):
    conexion = conectar_base_datos()
    try:
        return [dict(fila) for fila in conexion.execute(CONSULTA_RESERVAS +
                  ' WHERE r.codigo_estudiante = ? ORDER BY r.id_reserva DESC',
                  (codigo_estudiante.strip().upper(),))]
    finally:
        conexion.close()


def consultar_todas_las_reservas():
    conexion = conectar_base_datos()
    try:
        return [dict(fila) for fila in conexion.execute(CONSULTA_RESERVAS + ' ORDER BY r.id_reserva DESC')]
    finally:
        conexion.close()


def cancelar_reserva(id_reserva, codigo_estudiante):
    conexion = conectar_base_datos()
    try:
        conexion.execute('BEGIN IMMEDIATE')
        fila = conexion.execute("""SELECT fecha_inicio, hora_inicio, estado FROM reservas
            WHERE id_reserva = ? AND codigo_estudiante = ?""",
            (id_reserva, codigo_estudiante.strip().upper())).fetchone()
        if not fila:
            return False, 'La reserva no existe o no pertenece al estudiante.'
        if fila['estado'] not in ('Pendiente', 'Confirmada'):
            return False, 'Solo pueden cancelarse reservas pendientes o confirmadas.'
        hoy = date.today().isoformat()
        if fila['fecha_inicio'] < hoy or (fila['fecha_inicio'] == hoy and
            (not fila['hora_inicio'] or fila['hora_inicio'] <= datetime.now().strftime('%H:%M'))):
            return False, 'La reserva ya comenzó. Solicita asistencia al administrador.'
        conexion.execute('UPDATE reservas SET estado = ? WHERE id_reserva = ?', ('Cancelada', id_reserva))
        conexion.execute('INSERT INTO historial (codigo_estudiante, accion, descripcion) VALUES (?, ?, ?)',
                         (codigo_estudiante.strip().upper(), 'Reserva cancelada', f'Reserva {id_reserva}'))
        conexion.commit()
        return True, 'Reserva cancelada correctamente.'
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f'Error al cancelar: {error}'
    finally:
        conexion.close()


def actualizar_estado_reserva(id_reserva, nuevo_estado):
    if nuevo_estado not in ESTADOS_RESERVA:
        return False, 'Selecciona un estado válido.'
    conexion = conectar_base_datos()
    try:
        conexion.execute('BEGIN IMMEDIATE')
        fila = conexion.execute("""SELECT id_reserva, codigo_estudiante, estado, id_recurso,
            fecha_inicio, fecha_fin, hora_inicio, hora_fin FROM reservas WHERE id_reserva = ?""",
            (id_reserva,)).fetchone()
        if not fila:
            return False, 'No se encontró la reserva.'
        if fila['estado'] == nuevo_estado:
            return True, 'La reserva ya tiene ese estado.'
        if fila['estado'] in ESTADOS_QUE_NO_BLOQUEAN:
            return False, 'Una reserva cerrada no puede reabrirse. Registra una nueva reserva.'
        if nuevo_estado in ('Pendiente', 'Confirmada', 'En uso'):
            if buscar_solapamiento(conexion, fila['id_recurso'], fila['fecha_inicio'], fila['fecha_fin'],
                                  fila['hora_inicio'], fila['hora_fin'], excluir_id=id_reserva):
                return False, 'Hay otra reserva en esas fechas. No se puede cambiar a un estado activo.'
        conexion.execute('UPDATE reservas SET estado = ? WHERE id_reserva = ?', (nuevo_estado, id_reserva))
        conexion.execute('INSERT INTO historial (codigo_estudiante, accion, descripcion) VALUES (?, ?, ?)',
                         (fila['codigo_estudiante'], 'Cambio de estado', f'Reserva {id_reserva}: {nuevo_estado}'))
        conexion.commit()
        return True, 'Estado de reserva actualizado.'
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f'Error al actualizar estado: {error}'
    finally:
        conexion.close()
