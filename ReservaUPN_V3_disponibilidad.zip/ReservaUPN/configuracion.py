"""VALORES EDITABLES: solo datos de ejemplo y valores iniciales.

Los horarios y duraciones vigentes se leen de la tabla 'configuracion'.
Si quieres modificarlos, usa el panel del administrador (Configuración).
"""

# Se aplican al crear una base nueva. No reemplazan datos ya existentes.
CONFIGURACION_INICIAL = {
    "hora_apertura": "09:00",
    "hora_cierre": "21:00",
    "duracion_maxima_reserva_horas": "2",
    "duracion_prestamo_libros_dias": "3",
    "duraciones_permitidas": "1,1.5,2",
}

CATEGORIAS_INICIALES = [
    ("Computadoras", "Equipos informáticos para estudiantes"),
    ("Salas", "Espacios de estudio y trabajo grupal"),
    ("Libros", "Material bibliográfico"),
    ("Juegos", "Juegos de mesa educativos y recreativos"),
]

# Recursos de DEMOSTRACIÓN. No son inventario oficial de la UPN.
# Solo se insertan si alguien ejecuta cargar_datos_ejemplo.py explícitamente.
# Puedes cambiar nombres, códigos, ubicaciones y cantidades aquí.
RECURSOS_EJEMPLO = [
    ("PC-001", "Computadora 1", "Computadoras", "Laboratorio de cómputo"),
    ("SAL-001", "Sala de estudio 1", "Salas", "Pabellón de estudio"),
    ("LIB-001", "Introducción a la programación", "Libros", "Biblioteca"),
    ("JUE-001", "Ajedrez", "Juegos", "Área recreativa"),
]

ESTADOS_RECURSO = ["Disponible", "Mantenimiento", "Inactivo"]
ESTADOS_ESTUDIANTE = ["Activo", "Inactivo"]
ESTADOS_RESERVA = ["Pendiente", "Confirmada", "En uso", "Finalizada", "Cancelada", "Rechazada"]
ESTADOS_QUE_NO_BLOQUEAN = ["Cancelada", "Cancelado", "Rechazada", "Finalizada", "Completada", "Devuelta"]
