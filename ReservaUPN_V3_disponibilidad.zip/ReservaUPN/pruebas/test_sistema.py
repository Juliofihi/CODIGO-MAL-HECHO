"""Pruebas automatizadas sobre copia TEMPORAL, nunca sobre la base original.
Ejecutar desde la carpeta ReservaUPN: python -m unittest discover -s pruebas -v
"""
import os
import shutil
import sqlite3
import tempfile
import unittest
from datetime import date, timedelta
import database
import estudiantes
import administradores
import recursos
import reservas


class ReservaUPNPruebas(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ruta_original = database.RUTA_BASE_DATOS
        cls.temporal = tempfile.TemporaryDirectory(prefix='prueba_reservaupn_')
        cls.ruta_copia = os.path.join(cls.temporal.name, 'reservaupn.db')
        shutil.copy2(cls.ruta_original, cls.ruta_copia)
        database.RUTA_BASE_DATOS = cls.ruta_copia
        database.preparar_base_datos()
        cls.codigo1 = 'N00900001'
        cls.codigo2 = 'N00900002'
        cls.password = 'TestSegura2026!'

    @classmethod
    def tearDownClass(cls):
        database.RUTA_BASE_DATOS = cls.ruta_original
        cls.temporal.cleanup()

    def test_01_estructura_inicial(self):
        conexion = database.conectar_base_datos()
        try:
            self.assertEqual(conexion.execute('PRAGMA integrity_check').fetchone()[0], 'ok')
            tablas = {fila[0] for fila in conexion.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            self.assertTrue({'estudiantes', 'administradores', 'categorias', 'recursos',
                             'libros', 'juegos', 'reservas', 'historial', 'configuracion'} <= tablas)
            self.assertEqual(conexion.execute('SELECT COUNT(*) FROM recursos').fetchone()[0], 40)
        finally:
            conexion.close()

    def test_02_registro_y_login(self):
        bien, msg = administradores.crear_primer_administrador(
            'pruebaadmin', 'Admin', 'Prueba', 'pruebaadmin@example.com', self.password)
        self.assertTrue(bien, msg)
        self.assertIsNotNone(administradores.iniciar_sesion_admin('pruebaadmin', self.password))
        self.assertIsNone(administradores.iniciar_sesion_admin('pruebaadmin', 'incorrecta'))
        self.assertFalse(administradores.crear_primer_administrador(
            'segundo', 'Test', 'Prueba', 'segundo@example.com', self.password)[0])
        for numero, codigo in enumerate((self.codigo1, self.codigo2)):
            correo = f'{codigo.lower()}@upn.pe'
            bien, msg = estudiantes.registrar_estudiante(codigo, 'Prueba', f'Estudiante{numero}',
                                                         correo, '', self.password)
            self.assertTrue(bien, msg)
            self.assertIsNotNone(estudiantes.iniciar_sesion(correo, self.password))
            self.assertIsNone(estudiantes.iniciar_sesion(correo, 'incorrecta'))
        self.assertEqual(len(estudiantes.listar_estudiantes()), 2)
        bien, msg = estudiantes.modificar_estudiante(self.codigo2, 'Otro', 'Apellido',
                                                      'nuevo@upn.pe', '999000001', 'Activo')
        self.assertTrue(bien, msg)
        self.assertEqual(estudiantes.obtener_estudiante(self.codigo2)['nombres'], 'Otro')

    def test_03_categorias_y_recursos(self):
        categorias = recursos.listar_categorias()
        self.assertEqual(len(categorias), 4)
        bien, msg = recursos.agregar_categoria('Impresoras', 'Pruebas')
        self.assertTrue(bien, msg)
        id_categoria = next(c['id_categoria'] for c in recursos.listar_categorias()
                            if c['nombre_categoria'] == 'Impresoras')
        bien, msg = recursos.agregar_recurso(id_categoria, 'IMP-TEST01', 'Impresora', 'Tóner', 'Lab 1')
        self.assertTrue(bien, msg)
        bien, msg = recursos.modificar_recurso('IMP-TEST01', id_categoria,
                                               'IMP-TEST01', 'Impresora de prueba', 'Tóner', 'Lab 2', 'Disponible')
        self.assertTrue(bien, msg)
        self.assertEqual(recursos.obtener_recurso('IMP-TEST01')['ubicacion'], 'Lab 2')
        bien, msg = recursos.desactivar_recurso('IMP-TEST01')
        self.assertTrue(bien, msg)
        self.assertEqual(recursos.obtener_recurso('IMP-TEST01')['estado'], 'Inactivo')
        self.assertFalse(recursos.agregar_recurso(id_categoria, 'IMP-TEST01', 'Duplicada')[0])
        self.assertTrue(recursos.modificar_categoria(id_categoria, 'Impresoras y periféricos')[0])

    def test_04_reservas_por_horas_y_solapamientos(self):
        fecha = (date.today() + timedelta(days=10)).isoformat()
        bien, msg = reservas.crear_reserva(self.codigo1, 'PC-001', fecha, '10:00', 1.5)
        self.assertTrue(bien, msg)
        self.assertFalse(reservas.crear_reserva(self.codigo2, 'PC-001', fecha, '11:00', 1)[0])
        self.assertTrue(reservas.crear_reserva(self.codigo2, 'PC-001', fecha, '11:30', 1)[0])
        self.assertFalse(reservas.crear_reserva(self.codigo2, 'PC-001', fecha, '08:00', 1)[0])
        self.assertFalse(reservas.crear_reserva(self.codigo2, 'PC-002', fecha, '20:00', 2)[0])
        self.assertFalse(reservas.crear_reserva(self.codigo1, 'PC-002', fecha, '10:00', 3)[0])
        self.assertFalse(reservas.crear_reserva(self.codigo1, 'PC-002', '2020-01-01', '10:00', 1)[0])
        self.assertTrue(reservas.crear_reserva(self.codigo1, 'PC-002', fecha, '09:00', 1)[0])
        mis = reservas.consultar_reservas_estudiante(self.codigo1)
        id_reserva = next(r['id_reserva'] for r in mis if r['codigo_inventario'] == 'PC-001')
        self.assertTrue(reservas.cancelar_reserva(id_reserva, self.codigo1)[0])
        self.assertFalse(reservas.cancelar_reserva(id_reserva, self.codigo1)[0])
        self.assertTrue(reservas.crear_reserva(self.codigo2, 'PC-001', fecha, '10:00', 1)[0])
        self.assertFalse(reservas.actualizar_estado_reserva(id_reserva, 'Confirmada')[0])
        self.assertTrue(reservas.consultar_todas_las_reservas())

    def test_05_libros_y_estados(self):
        fecha = (date.today() + timedelta(days=15)).isoformat()
        tres_dias_despues = (date.today() + timedelta(days=18)).isoformat()
        self.assertTrue(reservas.crear_reserva(self.codigo1, 'LIB-001', fecha)[0])
        self.assertFalse(reservas.crear_reserva(self.codigo2, 'LIB-001',
                                                (date.today() + timedelta(days=16)).isoformat())[0])
        # Intervalos semiabiertos: el día de devolución puede comenzar otro préstamo.
        self.assertTrue(reservas.crear_reserva(self.codigo2, 'LIB-001', tres_dias_despues)[0])
        consulta = reservas.consultar_reservas_estudiante(self.codigo1)
        libro = next(r for r in consulta if r['codigo_inventario'] == 'LIB-001')
        self.assertEqual(libro['fecha_fin'], tres_dias_despues)
        self.assertTrue(reservas.actualizar_estado_reserva(libro['id_reserva'], 'Confirmada')[0])
        self.assertTrue(reservas.actualizar_estado_reserva(libro['id_reserva'], 'Finalizada')[0])
        self.assertFalse(reservas.actualizar_estado_reserva(libro['id_reserva'], 'Pendiente')[0])

    def test_06_metadatos_y_categorias_renombradas(self):
        categorias = recursos.listar_categorias()
        libros = next(c for c in categorias if c['nombre_categoria'] == 'Libros')
        juegos = next(c for c in categorias if c['nombre_categoria'] == 'Juegos')
        self.assertTrue(recursos.modificar_categoria(libros['id_categoria'], 'Biblioteca académica')[0])
        self.assertTrue(recursos.agregar_recurso(libros['id_categoria'], 'LIB-TEST', 'Libro nuevo',
            'Para clase', 'Biblioteca', 'Disponible',
            {'autor': 'Autor de prueba', 'editorial': 'Ejemplo', 'isbn': '000123',
             'area': 'Programación', 'anio_publicacion': '2026'})[0])
        self.assertEqual(recursos.obtener_recurso('LIB-TEST')['autor'], 'Autor de prueba')
        fecha = (date.today() + timedelta(days=28)).isoformat()
        self.assertTrue(reservas.crear_reserva(self.codigo1, 'LIB-TEST', fecha)[0])
        libro = next(r for r in reservas.consultar_reservas_estudiante(self.codigo1)
                     if r['codigo_inventario'] == 'LIB-TEST')
        self.assertIsNone(libro['hora_inicio'])
        self.assertEqual(libro['fecha_fin'], (date.today() + timedelta(days=31)).isoformat())
        self.assertTrue(recursos.agregar_recurso(juegos['id_categoria'], 'JUE-TEST', 'Juego nuevo',
            'Tablero', 'Zona común', 'Disponible',
            {'numero_jugadores': '4', 'descripcion_juego': 'Juego de prueba'})[0])
        self.assertEqual(recursos.obtener_recurso('JUE-TEST')['numero_jugadores'], 4)
        self.assertFalse(recursos.modificar_recurso('LIB-TEST', libros['id_categoria'], 'LIB-TEST',
            'Libro nuevo', 'Para clase', 'Biblioteca', 'Disponible', {'anio_publicacion': 'abc'})[0])
        self.assertEqual(recursos.obtener_recurso('LIB-TEST')['autor'], 'Autor de prueba')

    def test_07_reservas_concurrentes(self):
        from threading import Thread
        fecha = (date.today() + timedelta(days=35)).isoformat()
        respuestas = []

        def intentar(codigo):
            respuestas.append(reservas.crear_reserva(codigo, 'PC-003', fecha, '12:00', 1)[0])

        hilos = [Thread(target=intentar, args=(c,)) for c in (self.codigo1, self.codigo2)]
        for hilo in hilos:
            hilo.start()
        for hilo in hilos:
            hilo.join()
        self.assertEqual(sorted(respuestas), [False, True])

    def test_08_configuracion_y_exportacion(self):
        self.assertFalse(database.actualizar_configuracion('22:00', '08:00', '1,1.5,2', '3')[0])
        self.assertTrue(database.actualizar_configuracion('09:00', '21:00', '1,1.5,2', '3')[0])
        from reportes import exportar_reporte_completo
        from openpyxl import load_workbook
        salida = os.path.join(self.temporal.name, 'reporte_test.xlsx')
        bien, msg = exportar_reporte_completo(salida)
        self.assertTrue(bien, msg)
        libro = load_workbook(salida, read_only=True)
        self.assertEqual(libro.sheetnames, ['Reservas', 'Inventario', 'Estudiantes'])
        self.assertGreater(libro['Reservas'].max_row, 1)
        self.assertGreaterEqual(libro['Inventario'].max_row, 41)
        self.assertNotIn('contrasena_hash', list(libro['Estudiantes'].values)[0])
        libro.close()

    def test_09_reglas_de_estudiantes(self):
        registrar = estudiantes.registrar_estudiante
        # Códigos incorrectos
        for codigo in ('N0012345', 'N001234567', 'A00123456', 'n00 23456', ''):
            self.assertFalse(registrar(codigo, 'A', 'B', 'x@upn.pe', '', 'Clave12345')[0], codigo)
        # Correos que NO son institucionales
        for correo in ('alguien@gmail.com', 'alguien@outlook.com', 'alguien@hotmail.com',
                       'alguien@upn.pe.com', 'alguien@upn.edu.pe', '@upn.pe', 'sin_arroba', 'a b@upn.pe'):
            self.assertFalse(registrar('N00800001', 'A', 'B', correo, '', 'Clave12345')[0], correo)
        # El correo se acepta en mayúsculas y se guarda en minúsculas
        self.assertTrue(registrar('n00800001', 'Ana', 'Pérez', 'ANA.PEREZ@UPN.PE', '', 'Clave12345')[0])
        self.assertEqual(estudiantes.obtener_estudiante('N00800001')['correo'], 'ana.perez@upn.pe')
        datos = estudiantes.iniciar_sesion('Ana.Perez@upn.pe', 'Clave12345')
        self.assertEqual(datos['codigo_estudiante'], 'N00800001')
        # No se puede entrar con el código
        self.assertIsNone(estudiantes.iniciar_sesion('N00800001', 'Clave12345'))
        # Duplicados
        self.assertFalse(registrar('N00800001', 'Otra', 'Persona', 'otra@upn.pe', '', 'Clave12345')[0])
        self.assertFalse(registrar('N00800002', 'Otra', 'Persona', 'ana.perez@upn.pe', '', 'Clave12345')[0])
        # Contraseña corta
        self.assertFalse(registrar('N00800003', 'Luis', 'Díaz', 'luis@upn.pe', '', '123')[0])
        # La contraseña no se guarda como texto normal
        conexion = database.conectar_base_datos()
        try:
            guardado = conexion.execute("SELECT contrasena_hash FROM estudiantes WHERE codigo_estudiante = 'N00800001'").fetchone()[0]
        finally:
            conexion.close()
        self.assertNotIn('Clave12345', guardado)

    def test_10_administradores(self):
        principal = administradores.iniciar_sesion_admin('pruebaadmin', self.password)
        self.assertEqual(principal['es_principal'], 1)
        id_p = principal['id_administrador']
        # El principal crea administradores
        self.assertTrue(administradores.crear_administrador(id_p, 'segundo', 'Segundo', 'Admin',
                                                           'segundo@upn.pe', '', self.password)[0])
        self.assertFalse(administradores.crear_administrador(id_p, 'segundo', 'Otro', 'Admin',
                                                            'otro@upn.pe', '', self.password)[0])
        comun = administradores.iniciar_sesion_admin('segundo', self.password)
        self.assertEqual(comun['es_principal'], 0)
        id_c = comun['id_administrador']
        # Un administrador común no puede crear ni eliminar
        self.assertFalse(administradores.crear_administrador(id_c, 'tercero', 'T', 'A', 't@upn.pe', '', self.password)[0])
        self.assertFalse(administradores.eliminar_administrador(id_c, id_p)[0])
        # Un administrador común solo edita sus propios datos
        self.assertTrue(administradores.modificar_administrador(id_c, id_c, 'Segundo', 'Editado', 'segundo@upn.pe', '', 'Activo')[0])
        self.assertFalse(administradores.modificar_administrador(id_c, id_p, 'X', 'Y', 'x@upn.pe', '', 'Activo')[0])
        # El principal edita a cualquiera, pero no puede desactivarse
        self.assertTrue(administradores.modificar_administrador(id_p, id_c, 'Segundo', 'Admin', 'segundo@upn.pe', '', 'Inactivo')[0])
        self.assertIsNone(administradores.iniciar_sesion_admin('segundo', self.password))
        self.assertFalse(administradores.modificar_administrador(id_p, id_p, 'Admin', 'Prueba', 'p@upn.pe', '', 'Inactivo')[0])
        # Eliminar: no a sí mismo, no al principal, sí a otro
        self.assertFalse(administradores.eliminar_administrador(id_p, id_p)[0])
        self.assertTrue(administradores.eliminar_administrador(id_p, id_c)[0])
        self.assertEqual(len(administradores.listar_administradores()), 1)

    def test_11_eliminar_recursos_y_categorias(self):
        bien, msg = recursos.agregar_categoria('Categoria temporal', 'Prueba')
        self.assertTrue(bien, msg)
        id_cat = next(c['id_categoria'] for c in recursos.listar_categorias()
                      if c['nombre_categoria'] == 'Categoria temporal')
        self.assertTrue(recursos.agregar_recurso(id_cat, 'TMP-001', 'Recurso temporal')[0])
        self.assertFalse(recursos.eliminar_categoria(id_cat)[0])      # tiene un recurso
        self.assertTrue(recursos.eliminar_recurso('TMP-001')[0])
        self.assertIsNone(recursos.obtener_recurso('TMP-001'))
        self.assertTrue(recursos.eliminar_categoria(id_cat)[0])
        # Un recurso con reservas no se elimina
        self.assertFalse(recursos.eliminar_recurso('PC-001')[0])
        # Las categorías de Libros y Juegos están protegidas
        libros = next(c for c in recursos.listar_categorias() if c['nombre_categoria'] in ('Libros', 'Biblioteca académica'))
        self.assertFalse(recursos.eliminar_categoria(libros['id_categoria'])[0])

    def test_12_transferir_principal_y_eliminar(self):
        principal = administradores.iniciar_sesion_admin('pruebaadmin', self.password)
        id_p = principal['id_administrador']
        self.assertTrue(administradores.crear_administrador(id_p, 'tercero', 'Tercero', 'Admin',
                                                           'tercero@upn.pe', '', self.password)[0])
        id_t = administradores.iniciar_sesion_admin('tercero', self.password)['id_administrador']
        # Con más de un administrador, el principal no puede eliminarse a sí mismo
        self.assertFalse(administradores.eliminar_administrador(id_p, id_p)[0])
        # Un administrador común no puede transferir el rol
        self.assertFalse(administradores.transferir_principal(id_t, id_p)[0])
        # El principal transfiere el rol y el anterior ya no puede crear administradores
        self.assertTrue(administradores.transferir_principal(id_p, id_t)[0])
        self.assertFalse(administradores.crear_administrador(id_p, 'cuarto', 'C', 'A', 'c@upn.pe', '', self.password)[0])
        # El nuevo principal elimina al anterior
        self.assertTrue(administradores.eliminar_administrador(id_t, id_p)[0])
        # Siendo el único, puede eliminarse y el sistema vuelve al «Primer uso»
        self.assertTrue(administradores.eliminar_administrador(id_t, id_t)[0])
        self.assertFalse(administradores.existen_administradores())
        self.assertTrue(administradores.crear_primer_administrador('nuevo', 'N', 'A', 'n@upn.pe', self.password)[0])

    def test_13_disponibilidad_automatica(self):
        from datetime import datetime, timedelta
        conexion = database.conectar_base_datos()
        try:
            recurso = dict(conexion.execute(
                "SELECT id_recurso, codigo_inventario, estado FROM recursos WHERE codigo_inventario = 'PC-002'").fetchone())
            ahora = datetime.now()
            inicio = (ahora - timedelta(minutes=5)).strftime('%H:%M')
            fin = (ahora + timedelta(minutes=30)).strftime('%H:%M')
            if inicio > fin:          # cerca de medianoche: se omite esta comprobación
                return
            self.assertEqual(recursos.calcular_disponibilidad(conexion, recurso), 'Disponible')
            conexion.execute("""INSERT INTO reservas (codigo_estudiante, id_recurso, fecha_inicio, fecha_fin,
                hora_inicio, hora_fin, estado) VALUES (?, ?, ?, ?, ?, ?, 'Confirmada')""",
                (self.codigo1, recurso['id_recurso'], ahora.date().isoformat(), ahora.date().isoformat(), inicio, fin))
            conexion.commit()
            self.assertEqual(recursos.calcular_disponibilidad(conexion, recurso), 'Ocupado hasta ' + fin)
            lista = next(r for r in recursos.listar_recursos() if r['codigo_inventario'] == 'PC-002')
            self.assertEqual(lista['disponibilidad'], 'Ocupado hasta ' + fin)
            self.assertIn(inicio + ' a ' + fin, reservas.horarios_ocupados('PC-002', ahora.date().isoformat()))
            # Al cancelar la reserva, vuelve a mostrarse libre
            conexion.execute("UPDATE reservas SET estado = 'Cancelada' WHERE id_recurso = ?", (recurso['id_recurso'],))
            conexion.commit()
            self.assertEqual(recursos.calcular_disponibilidad(conexion, recurso), 'Disponible')
            # Mantenimiento se muestra tal cual
            recurso['estado'] = 'Mantenimiento'
            self.assertEqual(recursos.calcular_disponibilidad(conexion, recurso), 'Mantenimiento')
        finally:
            conexion.close()
        self.assertIsNone(reservas.horarios_ocupados('PC-002', 'fecha-mala'))


if __name__ == '__main__':
    unittest.main()
