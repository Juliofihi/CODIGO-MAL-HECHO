@echo off
cd /d "%~dp0"
echo Instalando OpenPyXL...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo No se pudieron instalar las dependencias.
  pause
  exit /b 1
)
echo.
echo Preparando la primera cuenta administrativa...
python crear_admin.py
pause
