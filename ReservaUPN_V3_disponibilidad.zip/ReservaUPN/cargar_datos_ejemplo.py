"""Opcional y manual: agregar ejemplos sin reiniciar ni eliminar información."""
from database import preparar_base_datos
from configuracion import RECURSOS_EJEMPLO
from recursos import listar_categorias, agregar_recurso


def main():
    preparar_base_datos()
    categorias = {fila['nombre_categoria']: fila['id_categoria'] for fila in listar_categorias()}
    for codigo, nombre, categoria, ubicacion in RECURSOS_EJEMPLO:
        if categoria in categorias:
            bien, mensaje = agregar_recurso(categorias[categoria], codigo, nombre,
                                            'Recurso de demostración', ubicacion)
            print(codigo, mensaje)
    print('No se eliminó ni sustituyó ningún recurso existente.')


if __name__ == '__main__':
    main()
