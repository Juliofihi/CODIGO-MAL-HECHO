"""Administradores: inicio de sesión y gestión (crear, consultar, editar y eliminar).

Regla principal: solo el ADMINISTRADOR PRINCIPAL puede crear o eliminar a otros
administradores. Un administrador común solo puede editar sus propios datos.
Los estudiantes no pueden crear cuentas de administrador.
"""
import sqlite3
from database import conectar_base_datos
from seguridad import crear_hash, verificar_contrasena, validar_contrasena

ESTADOS_ADMIN = ["Activo", "Inactivo"]


def validar_datos_admin(usuario, nombres, apellidos, correo):
    if not usuario or not nombres or not apellidos:
        return False, "Completa usuario, nombres y apellidos."
    if " " in usuario:
        return False, "El usuario no puede tener espacios."
    if correo.count('@') != 1 or ' ' in correo or '.' not in correo.split('@')[-1] or correo.startswith('@'):
        return False, "Ingresa un correo válido."
    return True, ""


def existen_administradores():
    conexion = conectar_base_datos()
    try:
        return conexion.execute("SELECT 1 FROM administradores LIMIT 1").fetchone() is not None
    finally:
        conexion.close()


def es_administrador_principal(id_administrador):
    """Consulta la base de datos (no se confía solo en lo que muestra la ventana)."""
    conexion = conectar_base_datos()
    try:
        fila = conexion.execute("""SELECT 1 FROM administradores
            WHERE id_administrador = ? AND es_principal = 1 AND estado = 'Activo'""",
                                (id_administrador,)).fetchone()
        return fila is not None
    finally:
        conexion.close()


def crear_primer_administrador(usuario, nombres, apellidos, correo, contrasena):
    """Crea al ADMINISTRADOR PRINCIPAL. Solo funciona cuando todavía no existe ningún administrador."""
    usuario = usuario.strip().lower()
    nombres, apellidos, correo = nombres.strip(), apellidos.strip(), correo.strip().lower()
    valido, mensaje = validar_datos_admin(usuario, nombres, apellidos, correo)
    if not valido:
        return False, mensaje
    valido, mensaje = validar_contrasena(contrasena)
    if not valido:
        return False, mensaje
    conexion = conectar_base_datos()
    try:
        conexion.execute("BEGIN IMMEDIATE")
        if conexion.execute("SELECT 1 FROM administradores LIMIT 1").fetchone():
            conexion.rollback()
            return False, "Ya existe un administrador. Usa esa cuenta para ingresar."
        conexion.execute("""INSERT INTO administradores
            (usuario, nombres, apellidos, correo, contrasena_hash, estado, es_principal)
            VALUES (?, ?, ?, ?, ?, 'Activo', 1)""",
            (usuario, nombres, apellidos, correo, crear_hash(contrasena)))
        conexion.commit()
        return True, "Administrador principal creado correctamente."
    except sqlite3.IntegrityError:
        conexion.rollback()
        return False, "El usuario o correo ya está registrado."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al crear administrador: {error}"
    finally:
        conexion.close()


def iniciar_sesion_admin(usuario, contrasena):
    if not usuario or not contrasena:
        return None
    conexion = conectar_base_datos()
    try:
        fila = conexion.execute("""SELECT id_administrador, usuario, nombres, apellidos,
            correo, es_principal, contrasena_hash FROM administradores
            WHERE usuario = ? AND estado = 'Activo'""", (usuario.strip().lower(),)).fetchone()
        if not fila or not verificar_contrasena(contrasena, fila['contrasena_hash']):
            return None
        return {clave: fila[clave] for clave in
                ("id_administrador", "usuario", "nombres", "apellidos", "correo", "es_principal")}
    finally:
        conexion.close()


def listar_administradores():
    conexion = conectar_base_datos()
    try:
        return [dict(fila) for fila in conexion.execute("""SELECT id_administrador, usuario, nombres,
            apellidos, correo, telefono, estado, es_principal FROM administradores
            ORDER BY es_principal DESC, apellidos, nombres""")]
    finally:
        conexion.close()


def crear_administrador(id_quien_crea, usuario, nombres, apellidos, correo, telefono, contrasena):
    """Solo el administrador principal puede crear administradores nuevos."""
    if not es_administrador_principal(id_quien_crea):
        return False, "Solo el administrador principal puede crear administradores."
    usuario = usuario.strip().lower()
    nombres, apellidos = nombres.strip(), apellidos.strip()
    correo, telefono = correo.strip().lower(), telefono.strip()
    valido, mensaje = validar_datos_admin(usuario, nombres, apellidos, correo)
    if not valido:
        return False, mensaje
    valido, mensaje = validar_contrasena(contrasena)
    if not valido:
        return False, mensaje
    conexion = conectar_base_datos()
    try:
        conexion.execute("""INSERT INTO administradores
            (usuario, nombres, apellidos, correo, telefono, contrasena_hash, estado, es_principal)
            VALUES (?, ?, ?, ?, ?, ?, 'Activo', 0)""",
            (usuario, nombres, apellidos, correo, telefono, crear_hash(contrasena)))
        conexion.commit()
        return True, "Administrador creado correctamente."
    except sqlite3.IntegrityError:
        conexion.rollback()
        return False, "El usuario o el correo ya está registrado."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al crear administrador: {error}"
    finally:
        conexion.close()


def modificar_administrador(id_quien_edita, id_administrador, nombres, apellidos, correo,
                            telefono, estado, nueva_contrasena=''):
    """El principal edita a cualquiera; un administrador común solo edita su propia cuenta."""
    es_principal = es_administrador_principal(id_quien_edita)
    if not es_principal and id_quien_edita != id_administrador:
        return False, "Solo puedes editar tus propios datos."
    nombres, apellidos = nombres.strip(), apellidos.strip()
    correo, telefono = correo.strip().lower(), telefono.strip()
    valido, mensaje = validar_datos_admin("x", nombres, apellidos, correo)
    if not valido:
        return False, mensaje
    if estado not in ESTADOS_ADMIN:
        return False, "Estado no válido."
    if nueva_contrasena:
        valido, mensaje = validar_contrasena(nueva_contrasena)
        if not valido:
            return False, mensaje
    conexion = conectar_base_datos()
    try:
        actual = conexion.execute("SELECT es_principal, estado FROM administradores WHERE id_administrador = ?",
                                  (id_administrador,)).fetchone()
        if not actual:
            return False, "No se encontró el administrador."
        if not es_principal:
            estado = actual['estado']          # un administrador común no cambia su propio estado
        if actual['es_principal'] == 1 and estado != 'Activo':
            return False, "El administrador principal no puede desactivarse."
        conexion.execute("""UPDATE administradores SET nombres = ?, apellidos = ?, correo = ?,
            telefono = ?, estado = ? WHERE id_administrador = ?""",
                         (nombres, apellidos, correo, telefono, estado, id_administrador))
        if nueva_contrasena:
            conexion.execute("UPDATE administradores SET contrasena_hash = ? WHERE id_administrador = ?",
                             (crear_hash(nueva_contrasena), id_administrador))
        conexion.commit()
        return True, "Datos del administrador actualizados."
    except sqlite3.IntegrityError:
        conexion.rollback()
        return False, "Ese correo ya pertenece a otro administrador."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al actualizar administrador: {error}"
    finally:
        conexion.close()


def transferir_principal(id_principal, id_nuevo_principal):
    """El administrador principal le pasa el rol a otro administrador activo.
    Después, el nuevo principal puede eliminar al anterior."""
    if not es_administrador_principal(id_principal):
        return False, "Solo el administrador principal puede transferir el rol."
    if id_principal == id_nuevo_principal:
        return False, "Ya eres el administrador principal."
    conexion = conectar_base_datos()
    try:
        conexion.execute("BEGIN IMMEDIATE")
        fila = conexion.execute("SELECT 1 FROM administradores WHERE id_administrador = ? AND estado = 'Activo'",
                                (id_nuevo_principal,)).fetchone()
        if not fila:
            conexion.rollback()
            return False, "El administrador elegido no existe o está inactivo."
        conexion.execute("UPDATE administradores SET es_principal = 0 WHERE id_administrador = ?", (id_principal,))
        conexion.execute("UPDATE administradores SET es_principal = 1 WHERE id_administrador = ?", (id_nuevo_principal,))
        conexion.commit()
        return True, "Rol de administrador principal transferido."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al transferir el rol: {error}"
    finally:
        conexion.close()


def eliminar_administrador(id_quien_elimina, id_administrador):
    """Solo el principal elimina administradores.
    - A otro administrador común: se puede.
    - A sí mismo: solo si es el ÚNICO administrador (el programa vuelve al «Primer uso»).
      Si hay más, primero debe transferir el rol de principal.
    La ventana pide confirmación antes de llamar a esta función."""
    if not es_administrador_principal(id_quien_elimina):
        return False, "Solo el administrador principal puede eliminar administradores."
    conexion = conectar_base_datos()
    try:
        fila = conexion.execute("SELECT es_principal FROM administradores WHERE id_administrador = ?",
                                (id_administrador,)).fetchone()
        if not fila:
            return False, "No se encontró el administrador."
        if id_quien_elimina == id_administrador:
            total = conexion.execute("SELECT COUNT(*) FROM administradores").fetchone()[0]
            if total > 1:
                return False, "Para eliminar tu cuenta primero usa «Hacer principal» con otro administrador."
        elif fila['es_principal'] == 1:
            return False, "No se puede eliminar al administrador principal."
        conexion.execute("DELETE FROM administradores WHERE id_administrador = ?", (id_administrador,))
        conexion.commit()
        return True, "Administrador eliminado."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al eliminar administrador: {error}"
    finally:
        conexion.close()
