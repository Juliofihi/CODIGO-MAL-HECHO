"""Elementos gráficos reutilizables, sencillos y sin librerías externas."""
import tkinter as tk
from tkinter import ttk, messagebox

AZUL = '#17365D'
FONDO = '#F3F6FA'


def encabezado(padre, titulo, subtitulo, salir):
    barra = tk.Frame(padre, bg=AZUL, pady=14)
    barra.pack(fill='x')
    tk.Label(barra, text=titulo, bg=AZUL, fg='white', font=('Segoe UI', 18, 'bold')).pack(side='left', padx=22)
    tk.Label(barra, text=subtitulo, bg=AZUL, fg='#DDE8F4', font=('Segoe UI', 10)).pack(side='left')
    tk.Button(barra, text='Cerrar sesión', command=salir, bg='#FFFFFF', fg=AZUL,
              relief='flat', padx=12, pady=6).pack(side='right', padx=22)


def titulo_seccion(padre, texto):
    ttk.Label(padre, text=texto, font=('Segoe UI', 14, 'bold')).pack(anchor='w', padx=12, pady=(12, 6))


def crear_tabla(padre, columnas, anchuras=None, altura=13):
    """columnas: lista de (identificador, título)."""
    contenedor = ttk.Frame(padre)
    contenedor.pack(fill='both', expand=True, padx=12, pady=8)
    nombres = [clave for clave, etiqueta in columnas]
    tabla = ttk.Treeview(contenedor, columns=nombres, show='headings', height=altura, selectmode='browse')
    for n, (clave, etiqueta) in enumerate(columnas):
        tabla.heading(clave, text=etiqueta)
        tabla.column(clave, width=(anchuras[n] if anchuras else 130), minwidth=75, anchor='w')
    lateral = ttk.Scrollbar(contenedor, orient='vertical', command=tabla.yview)
    inferior = ttk.Scrollbar(contenedor, orient='horizontal', command=tabla.xview)
    tabla.configure(yscrollcommand=lateral.set, xscrollcommand=inferior.set)
    contenedor.rowconfigure(0, weight=1)
    contenedor.columnconfigure(0, weight=1)
    tabla.grid(row=0, column=0, sticky='nsew')
    lateral.grid(row=0, column=1, sticky='ns')
    inferior.grid(row=1, column=0, sticky='ew')
    return tabla


def rellenar_tabla(tabla, filas, claves):
    for item in tabla.get_children():
        tabla.delete(item)
    for fila in filas:
        tabla.insert('', 'end', values=[fila.get(clave) if fila.get(clave) is not None else ''
                                        for clave in claves])


def seleccionado(tabla):
    seleccion = tabla.selection()
    if not seleccion:
        messagebox.showinfo('Selecciona un registro', 'Primero selecciona una fila de la tabla.')
        return None
    return tabla.item(seleccion[0], 'values')


def boton(padre, texto, accion):
    return ttk.Button(padre, text=texto, command=accion)


def crear_dialogo(padre, titulo):
    ventana = tk.Toplevel(padre)
    ventana.title(titulo)
    ventana.transient(padre.winfo_toplevel())
    ventana.grab_set()
    ventana.resizable(True, False)
    marco = ttk.Frame(ventana, padding=18)
    marco.pack(fill='both', expand=True)
    return ventana, marco


def campo_texto(marco, etiqueta, valor='', fila=0, secreto=False):
    ttk.Label(marco, text=etiqueta).grid(row=fila, column=0, sticky='w', padx=5, pady=6)
    entrada = ttk.Entry(marco, width=42, show='*' if secreto else '')
    entrada.insert(0, str(valor or ''))
    entrada.grid(row=fila, column=1, sticky='ew', padx=5, pady=6)
    return entrada


def campo_opciones(marco, etiqueta, opciones, seleccionado_valor='', fila=0):
    ttk.Label(marco, text=etiqueta).grid(row=fila, column=0, sticky='w', padx=5, pady=6)
    opciones = list(opciones)
    combo = ttk.Combobox(marco, values=opciones, state='readonly', width=39)
    if seleccionado_valor in opciones:
        combo.set(seleccionado_valor)
    elif opciones:
        combo.current(0)
    combo.grid(row=fila, column=1, sticky='ew', padx=5, pady=6)
    return combo
