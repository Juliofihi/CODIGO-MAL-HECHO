"""Catálogo, inventario y categorías. No borra recursos con historial."""
import sqlite3
from datetime import datetime
from database import conectar_base_datos
from configuracion import ESTADOS_RECURSO, ESTADOS_QUE_NO_BLOQUEAN

RECURSO_SELECT = """SELECT r.id_recurso, r.codigo_inventario, r.nombre, r.id_categoria,
    c.nombre_categoria, r.descripcion, r.ubicacion, r.estado,
    l.autor, l.editorial, l.isbn, l.area, l.anio_publicacion,
    j.numero_jugadores, j.descripcion_juego
    FROM recursos r JOIN categorias c ON c.id_categoria = r.id_categoria
    LEFT JOIN libros l ON l.id_recurso = r.id_recurso
    LEFT JOIN juegos j ON j.id_recurso = r.id_recurso"""


def listar_categorias():
    conexion = conectar_base_datos()
    try:
        return [dict(fila) for fila in conexion.execute(
            "SELECT id_categoria, nombre_categoria, descripcion FROM categorias ORDER BY nombre_categoria")]
    finally:
        conexion.close()


def agregar_categoria(nombre, descripcion=''):
    if not nombre.strip():
        return False, "El nombre de categoría es obligatorio."
    conexion = conectar_base_datos()
    try:
        conexion.execute("INSERT INTO categorias (nombre_categoria, descripcion) VALUES (?, ?)",
                         (nombre.strip(), descripcion.strip()))
        conexion.commit()
        return True, "Categoría registrada."
    except sqlite3.IntegrityError:
        return False, "Esa categoría ya existe."
    except sqlite3.Error as error:
        return False, f"Error al guardar categoría: {error}"
    finally:
        conexion.close()


def modificar_categoria(id_categoria, nombre, descripcion=''):
    if not nombre.strip():
        return False, "El nombre de categoría es obligatorio."
    conexion = conectar_base_datos()
    try:
        cursor = conexion.execute("UPDATE categorias SET nombre_categoria = ?, descripcion = ? WHERE id_categoria = ?",
                                  (nombre.strip(), descripcion.strip(), id_categoria))
        if cursor.rowcount == 0:
            return False, "No se encontró la categoría."
        conexion.commit()
        return True, "Categoría actualizada."
    except sqlite3.IntegrityError:
        return False, "Ya hay otra categoría con ese nombre."
    except sqlite3.Error as error:
        return False, f"Error al actualizar: {error}"
    finally:
        conexion.close()


def calcular_disponibilidad(conexion, recurso):
    """Dice si el recurso está libre AHORA, mirando las reservas (se calcula solo, no se escribe a mano).
    Resultados: 'Disponible', 'Ocupado hasta HH:MM', 'Prestado hasta AAAA-MM-DD',
    o el estado guardado si el recurso está en Mantenimiento o Inactivo."""
    if recurso['estado'] != 'Disponible':
        return recurso['estado']
    ahora = datetime.now()
    hoy, hora = ahora.date().isoformat(), ahora.strftime('%H:%M')
    marcas = ','.join('?' for _ in ESTADOS_QUE_NO_BLOQUEAN)
    base = ("SELECT hora_fin, fecha_fin FROM reservas WHERE id_recurso = ? "
            "AND COALESCE(estado, 'Pendiente') NOT IN (" + marcas + ") ")
    fijos = [recurso['id_recurso']] + ESTADOS_QUE_NO_BLOQUEAN
    # Reserva por horas (computadoras, salas, juegos) que está en curso ahora
    fila = conexion.execute(base + "AND hora_inicio IS NOT NULL AND fecha_inicio = ? "
                            "AND hora_inicio <= ? AND hora_fin > ?", fijos + [hoy, hora, hora]).fetchone()
    if fila:
        return 'Ocupado hasta ' + fila['hora_fin']
    # Libro prestado por días
    fila = conexion.execute(base + "AND hora_inicio IS NULL AND fecha_inicio <= ? AND fecha_fin > ?",
                            fijos + [hoy, hoy]).fetchone()
    if fila:
        return 'Prestado hasta ' + fila['fecha_fin']
    return 'Disponible'


def listar_recursos(categoria=None, incluir_inactivos=False):
    conexion = conectar_base_datos()
    try:
        consulta = RECURSO_SELECT + " WHERE 1=1"
        parametros = []
        if categoria and categoria != "Todas":
            consulta += " AND c.nombre_categoria = ?"
            parametros.append(categoria)
        if not incluir_inactivos:
            consulta += " AND r.estado <> 'Inactivo'"
        consulta += " ORDER BY c.nombre_categoria, r.codigo_inventario"
        lista = [dict(fila) for fila in conexion.execute(consulta, parametros)]
        for recurso in lista:
            recurso['disponibilidad'] = calcular_disponibilidad(conexion, recurso)
        return lista
    finally:
        conexion.close()


def obtener_recurso(codigo):
    conexion = conectar_base_datos()
    try:
        fila = conexion.execute(RECURSO_SELECT + " WHERE r.codigo_inventario = ?",
                                (codigo.strip().upper(),)).fetchone()
        return dict(fila) if fila else None
    finally:
        conexion.close()


def validar_recurso(categoria, codigo, nombre, estado):
    if not str(categoria).isdigit() or not codigo.strip() or not nombre.strip():
        return False, "Indica categoría, código de inventario y nombre."
    if estado not in ESTADOS_RECURSO:
        return False, "Estado del recurso no válido."
    return True, ""


def guardar_detalles(conexion, id_recurso, categoria_id, detalles):
    """Los datos especiales se guardan en las tablas libros/juegos existentes."""
    if detalles is None:
        return
    ids = {fila['clave']: fila['valor'] for fila in conexion.execute(
        "SELECT clave, valor FROM configuracion WHERE clave IN ('id_categoria_libros', 'id_categoria_juegos')")}
    if str(categoria_id) == ids.get('id_categoria_libros'):
        año_texto = str(detalles.get('anio_publicacion', '') or '').strip()
        if año_texto and (not año_texto.isdigit() or not 1400 <= int(año_texto) <= 2200):
            raise ValueError('El año del libro debe ser un número entre 1400 y 2200.')
        conexion.execute("""INSERT OR REPLACE INTO libros
            (id_recurso, autor, editorial, isbn, area, anio_publicacion)
            VALUES (?, ?, ?, ?, ?, ?)""", (
            id_recurso, detalles.get('autor', '').strip(), detalles.get('editorial', '').strip(),
            detalles.get('isbn', '').strip(), detalles.get('area', '').strip(),
            int(año_texto) if año_texto else None))
    elif str(categoria_id) == ids.get('id_categoria_juegos'):
        jugadores_texto = str(detalles.get('numero_jugadores', '') or '').strip()
        if jugadores_texto and (not jugadores_texto.isdigit() or not 1 <= int(jugadores_texto) <= 100):
            raise ValueError('El número de jugadores debe ser de 1 a 100.')
        conexion.execute("""INSERT OR REPLACE INTO juegos
            (id_recurso, numero_jugadores, descripcion_juego) VALUES (?, ?, ?)""", (
            id_recurso, int(jugadores_texto) if jugadores_texto else None,
            detalles.get('descripcion_juego', '').strip()))


def agregar_recurso(categoria_id, codigo, nombre, descripcion='', ubicacion='', estado='Disponible', detalles=None):
    valido, mensaje = validar_recurso(categoria_id, codigo, nombre, estado)
    if not valido:
        return False, mensaje
    conexion = conectar_base_datos()
    try:
        cursor = conexion.execute("""INSERT INTO recursos
            (id_categoria, codigo_inventario, nombre, descripcion, ubicacion, estado)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (int(categoria_id), codigo.strip().upper(), nombre.strip(), descripcion.strip(), ubicacion.strip(), estado))
        guardar_detalles(conexion, cursor.lastrowid, categoria_id, detalles)
        conexion.commit()
        return True, "Recurso registrado."
    except sqlite3.IntegrityError:
        conexion.rollback()
        return False, "El código de inventario ya existe o la categoría no es válida."
    except (sqlite3.Error, ValueError) as error:
        conexion.rollback()
        return False, f"Error al registrar recurso: {error}"
    finally:
        conexion.close()


def modificar_recurso(codigo_original, categoria_id, codigo_nuevo, nombre, descripcion, ubicacion, estado, detalles=None):
    valido, mensaje = validar_recurso(categoria_id, codigo_nuevo, nombre, estado)
    if not valido:
        return False, mensaje
    conexion = conectar_base_datos()
    try:
        cursor = conexion.execute("""UPDATE recursos SET id_categoria = ?, codigo_inventario = ?,
            nombre = ?, descripcion = ?, ubicacion = ?, estado = ? WHERE codigo_inventario = ?""",
            (int(categoria_id), codigo_nuevo.strip().upper(), nombre.strip(), descripcion.strip(),
             ubicacion.strip(), estado, codigo_original.strip().upper()))
        if cursor.rowcount == 0:
            return False, "No se encontró el recurso."
        fila = conexion.execute("SELECT id_recurso FROM recursos WHERE codigo_inventario = ?",
                                (codigo_nuevo.strip().upper(),)).fetchone()
        guardar_detalles(conexion, fila['id_recurso'], categoria_id, detalles)
        conexion.commit()
        return True, "Recurso actualizado."
    except sqlite3.IntegrityError:
        conexion.rollback()
        return False, "Código repetido o categoría inválida."
    except (sqlite3.Error, ValueError) as error:
        conexion.rollback()
        return False, f"Error al modificar recurso: {error}"
    finally:
        conexion.close()


def cambiar_estado_recurso(codigo, nuevo_estado):
    recurso = obtener_recurso(codigo)
    if not recurso:
        return False, "Recurso no encontrado."
    return modificar_recurso(codigo, recurso['id_categoria'], recurso['codigo_inventario'],
                            recurso['nombre'], recurso['descripcion'] or '', recurso['ubicacion'] or '', nuevo_estado)


def desactivar_recurso(codigo):
    # Evita DELETE: conserva registros y permite reactivarlo más tarde.
    return cambiar_estado_recurso(codigo, 'Inactivo')


def eliminar_recurso(codigo):
    """Elimina un recurso SOLO si nunca tuvo reservas. Si tiene historial, se debe desactivar."""
    codigo = codigo.strip().upper()
    conexion = conectar_base_datos()
    try:
        fila = conexion.execute("SELECT id_recurso FROM recursos WHERE codigo_inventario = ?", (codigo,)).fetchone()
        if not fila:
            return False, "Recurso no encontrado."
        id_recurso = fila['id_recurso']
        if conexion.execute("SELECT 1 FROM reservas WHERE id_recurso = ? LIMIT 1", (id_recurso,)).fetchone():
            return False, "Este recurso tiene reservas en su historial. Usa «Desactivar» para conservarlas."
        conexion.execute("DELETE FROM libros WHERE id_recurso = ?", (id_recurso,))
        conexion.execute("DELETE FROM juegos WHERE id_recurso = ?", (id_recurso,))
        conexion.execute("DELETE FROM recursos WHERE id_recurso = ?", (id_recurso,))
        conexion.commit()
        return True, "Recurso eliminado."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al eliminar recurso: {error}"
    finally:
        conexion.close()


def eliminar_categoria(id_categoria):
    """Elimina una categoría solo si no tiene recursos y no es la de Libros ni la de Juegos."""
    conexion = conectar_base_datos()
    try:
        especiales = [fila['valor'] for fila in conexion.execute(
            "SELECT valor FROM configuracion WHERE clave IN ('id_categoria_libros', 'id_categoria_juegos')")]
        if str(id_categoria) in especiales:
            return False, "Las categorías de Libros y Juegos no se pueden eliminar (tienen reglas especiales)."
        if conexion.execute("SELECT 1 FROM recursos WHERE id_categoria = ? LIMIT 1", (id_categoria,)).fetchone():
            return False, "La categoría tiene recursos. Cámbialos de categoría o elimínalos primero."
        cursor = conexion.execute("DELETE FROM categorias WHERE id_categoria = ?", (id_categoria,))
        if cursor.rowcount == 0:
            return False, "No se encontró la categoría."
        conexion.commit()
        return True, "Categoría eliminada."
    except sqlite3.Error as error:
        conexion.rollback()
        return False, f"Error al eliminar categoría: {error}"
    finally:
        conexion.close()
