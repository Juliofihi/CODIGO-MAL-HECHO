@echo off
cd /d "%~dp0"
python menu.py
if errorlevel 1 (
  echo.
  echo Si Python no se encuentra, revisa que este instalado y agregado al PATH.
  pause
)
