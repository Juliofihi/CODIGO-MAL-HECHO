"""Contraseñas con hash y sal, usando solamente la biblioteca de Python."""
import os
import hashlib
import hmac

ITERACIONES = 260000


def validar_contrasena(contrasena):
    if len(contrasena) < 8:
        return False, "La contraseña debe tener al menos 8 caracteres."
    return True, ""


def crear_hash(contrasena):
    sal = os.urandom(16)
    resumen = hashlib.pbkdf2_hmac('sha256', contrasena.encode('utf-8'), sal, ITERACIONES)
    return f"pbkdf2_sha256${ITERACIONES}${sal.hex()}${resumen.hex()}"


def verificar_contrasena(contrasena, hash_guardado):
    try:
        algoritmo, cantidad, sal, hash_original = hash_guardado.split('$')
        iteraciones = int(cantidad)
        if algoritmo != 'pbkdf2_sha256' or iteraciones < 1 or iteraciones > 2000000:
            return False
        calculado = hashlib.pbkdf2_hmac('sha256', contrasena.encode('utf-8'),
                                       bytes.fromhex(sal), iteraciones)
        return hmac.compare_digest(calculado, bytes.fromhex(hash_original))
    except (ValueError, TypeError, AttributeError):
        return False
