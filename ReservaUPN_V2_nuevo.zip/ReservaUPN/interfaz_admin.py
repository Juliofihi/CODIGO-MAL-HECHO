"""Panel de administración: estudiantes, recursos, categorías, reservas y Excel."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from interfaz_util import (encabezado, titulo_seccion, crear_tabla, rellenar_tabla,
                           seleccionado, boton, crear_dialogo, campo_texto, campo_opciones)
from estudiantes import listar_estudiantes, registrar_estudiante, modificar_estudiante
from recursos import (listar_recursos, listar_categorias, agregar_recurso, modificar_recurso,
                      desactivar_recurso, eliminar_recurso, agregar_categoria, modificar_categoria,
                      eliminar_categoria)
from administradores import (listar_administradores, crear_administrador, modificar_administrador,
                             eliminar_administrador, transferir_principal, ESTADOS_ADMIN)
from reservas import consultar_todas_las_reservas, actualizar_estado_reserva
from database import obtener_configuracion, actualizar_configuracion
from configuracion import ESTADOS_ESTUDIANTE, ESTADOS_RECURSO, ESTADOS_RESERVA


class PanelAdministrador(ttk.Frame):
    def __init__(self, padre, administrador, cerrar_sesion):
        super().__init__(padre)
        self.administrador = administrador
        self.cerrar_sesion = cerrar_sesion
        self.es_principal = administrador['es_principal'] == 1
        rol = 'Administrador principal' if self.es_principal else 'Administrador'
        encabezado(self, 'ReservaUPN', rol + ': ' + administrador['nombres'], cerrar_sesion)
        pestañas = ttk.Notebook(self)
        pestañas.pack(fill='both', expand=True, padx=14, pady=14)
        self.panel_estudiantes = ttk.Frame(pestañas)
        self.panel_recursos = ttk.Frame(pestañas)
        self.panel_categorias = ttk.Frame(pestañas)
        self.panel_reservas = ttk.Frame(pestañas)
        self.panel_config = ttk.Frame(pestañas)
        self.panel_excel = ttk.Frame(pestañas)
        self.panel_admins = ttk.Frame(pestañas)
        for marco, titulo in (
            (self.panel_estudiantes, 'Estudiantes'), (self.panel_recursos, 'Inventario'),
            (self.panel_categorias, 'Categorías'), (self.panel_reservas, 'Reservas'),
            (self.panel_config, 'Configuración'), (self.panel_excel, 'Reportes Excel'),
            (self.panel_admins, 'Administradores')):
            pestañas.add(marco, text=titulo)
        self.armar_estudiantes()
        self.armar_recursos()
        self.armar_categorias()
        self.armar_reservas()
        self.armar_configuracion()
        self.armar_excel()
        self.armar_admins()
        self.actualizar_admins()
        self.actualizar_estudiantes()
        self.actualizar_categorias()
        self.actualizar_recursos()
        self.actualizar_reservas()

    # --- Estudiantes ---
    def armar_estudiantes(self):
        titulo_seccion(self.panel_estudiantes, 'Estudiantes registrados')
        acciones = ttk.Frame(self.panel_estudiantes)
        acciones.pack(fill='x', padx=12)
        for texto, accion in [('Nuevo estudiante', lambda: self.formulario_estudiante()),
                              ('Editar seleccionado', self.editar_estudiante),
                              ('Actualizar', self.actualizar_estudiantes)]:
            boton(acciones, texto, accion).pack(side='left', padx=(0, 8))
        self.tabla_estudiantes = crear_tabla(self.panel_estudiantes,
            [('codigo_estudiante', 'Código'), ('nombres', 'Nombres'), ('apellidos', 'Apellidos'),
             ('correo', 'Correo'), ('telefono', 'Teléfono'), ('estado', 'Estado')],
            [125, 170, 170, 260, 125, 100])

    def actualizar_estudiantes(self):
        self.lista_estudiantes = listar_estudiantes()
        rellenar_tabla(self.tabla_estudiantes, self.lista_estudiantes,
                       ['codigo_estudiante', 'nombres', 'apellidos', 'correo', 'telefono', 'estado'])

    def editar_estudiante(self):
        fila = seleccionado(self.tabla_estudiantes)
        if fila:
            datos = next((e for e in self.lista_estudiantes if e['codigo_estudiante'] == fila[0]), None)
            if datos:
                self.formulario_estudiante(datos)

    def formulario_estudiante(self, datos=None):
        editar = datos is not None
        dialogo, marco = crear_dialogo(self, 'Editar estudiante' if editar else 'Nuevo estudiante')
        codigo = campo_texto(marco, 'Código (N00 + 6 caracteres)', (datos or {}).get('codigo_estudiante', ''), 0)
        if editar:
            codigo.configure(state='disabled')
        nombres = campo_texto(marco, 'Nombres', (datos or {}).get('nombres', ''), 1)
        apellidos = campo_texto(marco, 'Apellidos', (datos or {}).get('apellidos', ''), 2)
        correo = campo_texto(marco, 'Correo UPN (@UPN.PE)', (datos or {}).get('correo', ''), 3)
        telefono = campo_texto(marco, 'Teléfono', (datos or {}).get('telefono', ''), 4)
        estado = campo_opciones(marco, 'Estado', ESTADOS_ESTUDIANTE, (datos or {}).get('estado', 'Activo'), 5)
        contrasena = campo_texto(marco, 'Nueva contraseña (8+)', '', 6, secreto=True)
        ttk.Label(marco, text='Al editar, deja la contraseña vacía para conservar la actual.',
                  foreground='#51687E').grid(row=7, column=0, columnspan=2, pady=7)

        def guardar():
            if editar:
                bien, mensaje = modificar_estudiante(datos['codigo_estudiante'], nombres.get(), apellidos.get(),
                                                     correo.get(), telefono.get(), estado.get(), contrasena.get())
            else:
                bien, mensaje = registrar_estudiante(codigo.get(), nombres.get(), apellidos.get(),
                                                     correo.get(), telefono.get(), contrasena.get())
            if bien:
                dialogo.destroy()
                self.actualizar_estudiantes()
                messagebox.showinfo('Estudiantes', mensaje)
            else:
                messagebox.showwarning('Revisar datos', mensaje, parent=dialogo)
        boton(marco, 'Guardar estudiante', guardar).grid(row=8, column=1, sticky='e', pady=12)

    # --- Recursos ---
    def armar_recursos(self):
        titulo_seccion(self.panel_recursos, 'Inventario de recursos')
        acciones = ttk.Frame(self.panel_recursos)
        acciones.pack(fill='x', padx=12)
        for texto, accion in [('Nuevo recurso', lambda: self.formulario_recurso()),
                              ('Editar seleccionado', self.editar_recurso),
                              ('Desactivar', self.desactivar_seleccionado),
                              ('Eliminar', self.eliminar_seleccionado),
                              ('Actualizar', self.actualizar_recursos)]:
            boton(acciones, texto, accion).pack(side='left', padx=(0, 8))
        self.tabla_recursos = crear_tabla(self.panel_recursos,
            [('codigo_inventario', 'Código'), ('nombre', 'Nombre'), ('nombre_categoria', 'Categoría'),
             ('ubicacion', 'Ubicación'), ('estado', 'Estado'), ('descripcion', 'Descripción')],
            [120, 220, 150, 200, 120, 260])
        ttk.Label(self.panel_recursos, text='Desactivar conserva el historial (para reactivar, edita y elige Disponible). '
                  'Eliminar solo funciona si el recurso nunca tuvo reservas.',
                  foreground='#51687E').pack(anchor='w', padx=12, pady=6)

    def actualizar_recursos(self):
        self.lista_recursos = listar_recursos(incluir_inactivos=True)
        rellenar_tabla(self.tabla_recursos, self.lista_recursos,
                       ['codigo_inventario', 'nombre', 'nombre_categoria', 'ubicacion', 'estado', 'descripcion'])

    def editar_recurso(self):
        fila = seleccionado(self.tabla_recursos)
        if fila:
            datos = next((r for r in self.lista_recursos if r['codigo_inventario'] == fila[0]), None)
            if datos:
                self.formulario_recurso(datos)

    def formulario_recurso(self, datos=None):
        editar = datos is not None
        categorias = listar_categorias()
        if not categorias:
            messagebox.showwarning('Categorías', 'Primero registra una categoría.')
            return
        dialogo, marco = crear_dialogo(self, 'Editar recurso' if editar else 'Nuevo recurso')
        codigo = campo_texto(marco, 'Código de inventario', (datos or {}).get('codigo_inventario', ''), 0)
        nombre = campo_texto(marco, 'Nombre', (datos or {}).get('nombre', ''), 1)
        nombres_cat = [c['nombre_categoria'] for c in categorias]
        categoria = campo_opciones(marco, 'Categoría', nombres_cat, (datos or {}).get('nombre_categoria', ''), 2)
        descripcion = campo_texto(marco, 'Descripción', (datos or {}).get('descripcion', ''), 3)
        ubicacion = campo_texto(marco, 'Ubicación', (datos or {}).get('ubicacion', ''), 4)
        estado = campo_opciones(marco, 'Estado', ESTADOS_RECURSO, (datos or {}).get('estado', 'Disponible'), 5)
        ids = {c['nombre_categoria']: c['id_categoria'] for c in categorias}
        configuracion = obtener_configuracion()
        # Tablas "libros" y "juegos" ya existen en la base original.
        # Los campos extra aparecen solo para la categoría correspondiente.
        campos_libro = {
            'autor': campo_texto(marco, 'Autor (libro)', (datos or {}).get('autor', ''), 6),
            'editorial': campo_texto(marco, 'Editorial (libro)', (datos or {}).get('editorial', ''), 7),
            'isbn': campo_texto(marco, 'ISBN (libro)', (datos or {}).get('isbn', ''), 8),
            'area': campo_texto(marco, 'Área (libro)', (datos or {}).get('area', ''), 9),
            'anio_publicacion': campo_texto(marco, 'Año publicación', (datos or {}).get('anio_publicacion', ''), 10),
        }
        campos_juego = {
            'numero_jugadores': campo_texto(marco, 'Cantidad de jugadores',
                                          (datos or {}).get('numero_jugadores', ''), 11),
            'descripcion_juego': campo_texto(marco, 'Descripción del juego',
                                            (datos or {}).get('descripcion_juego', ''), 12),
        }

        def mostrar_campos(evento=None):
            categoria_id = str(ids[categoria.get()])
            mostrar_libro = categoria_id == configuracion.get('id_categoria_libros')
            mostrar_juego = categoria_id == configuracion.get('id_categoria_juegos')
            for fila in range(6, 13):
                mostrar = (fila <= 10 and mostrar_libro) or (fila >= 11 and mostrar_juego)
                for widget in marco.grid_slaves(row=fila):
                    if mostrar:
                        widget.grid()
                    else:
                        widget.grid_remove()

        categoria.bind('<<ComboboxSelected>>', mostrar_campos)
        mostrar_campos()

        def guardar():
            detalles = {nombre: campo.get() for nombre, campo in {**campos_libro, **campos_juego}.items()}
            if editar:
                bien, mensaje = modificar_recurso(datos['codigo_inventario'], ids[categoria.get()], codigo.get(),
                                                  nombre.get(), descripcion.get(), ubicacion.get(), estado.get(), detalles)
            else:
                bien, mensaje = agregar_recurso(ids[categoria.get()], codigo.get(), nombre.get(),
                                                descripcion.get(), ubicacion.get(), estado.get(), detalles)
            if bien:
                dialogo.destroy()
                self.actualizar_recursos()
                messagebox.showinfo('Inventario', mensaje)
            else:
                messagebox.showwarning('Revisar datos', mensaje, parent=dialogo)
        boton(marco, 'Guardar recurso', guardar).grid(row=13, column=1, sticky='e', pady=12)

    def desactivar_seleccionado(self):
        fila = seleccionado(self.tabla_recursos)
        if fila and messagebox.askyesno('Confirmar', '¿Desactivar ' + fila[0] + '?'):
            bien, mensaje = desactivar_recurso(fila[0])
            if bien:
                self.actualizar_recursos()
                messagebox.showinfo('Inventario', mensaje)
            else:
                messagebox.showwarning('Inventario', mensaje)

    def eliminar_seleccionado(self):
        fila = seleccionado(self.tabla_recursos)
        if fila and messagebox.askyesno('Confirmar eliminación',
                                        '¿Eliminar definitivamente el recurso ' + fila[0] + '?\nNo se puede deshacer.'):
            bien, mensaje = eliminar_recurso(fila[0])
            if bien:
                self.actualizar_recursos()
                messagebox.showinfo('Inventario', mensaje)
            else:
                messagebox.showwarning('Inventario', mensaje)

    # --- Categorías ---
    def armar_categorias(self):
        titulo_seccion(self.panel_categorias, 'Categorías del inventario')
        acciones = ttk.Frame(self.panel_categorias)
        acciones.pack(fill='x', padx=12)
        boton(acciones, 'Agregar categoría', lambda: self.formulario_categoria()).pack(side='left')
        boton(acciones, 'Editar seleccionada', self.editar_categoria).pack(side='left', padx=8)
        boton(acciones, 'Eliminar seleccionada', self.eliminar_categoria_seleccionada).pack(side='left')
        boton(acciones, 'Actualizar', self.actualizar_categorias).pack(side='left', padx=8)
        self.tabla_categorias = crear_tabla(self.panel_categorias,
            [('id_categoria', 'ID'), ('nombre_categoria', 'Nombre'), ('descripcion', 'Descripción')], [65, 220, 440])

    def actualizar_categorias(self):
        self.lista_categorias = listar_categorias()
        rellenar_tabla(self.tabla_categorias, self.lista_categorias,
                       ['id_categoria', 'nombre_categoria', 'descripcion'])

    def editar_categoria(self):
        fila = seleccionado(self.tabla_categorias)
        if fila:
            datos = next((c for c in self.lista_categorias if str(c['id_categoria']) == str(fila[0])), None)
            if datos:
                self.formulario_categoria(datos)

    def eliminar_categoria_seleccionada(self):
        fila = seleccionado(self.tabla_categorias)
        if fila and messagebox.askyesno('Confirmar eliminación',
                                        '¿Eliminar la categoría «' + str(fila[1]) + '»?'):
            bien, mensaje = eliminar_categoria(int(fila[0]))
            if bien:
                self.actualizar_categorias()
                messagebox.showinfo('Categorías', mensaje)
            else:
                messagebox.showwarning('Categorías', mensaje)

    def formulario_categoria(self, datos=None):
        dialogo, marco = crear_dialogo(self, 'Editar categoría' if datos else 'Agregar categoría')
        nombre = campo_texto(marco, 'Nombre', (datos or {}).get('nombre_categoria', ''), 0)
        descripcion = campo_texto(marco, 'Descripción', (datos or {}).get('descripcion', ''), 1)

        def guardar():
            if datos:
                bien, mensaje = modificar_categoria(datos['id_categoria'], nombre.get(), descripcion.get())
            else:
                bien, mensaje = agregar_categoria(nombre.get(), descripcion.get())
            if bien:
                dialogo.destroy()
                self.actualizar_categorias()
                messagebox.showinfo('Categorías', mensaje)
            else:
                messagebox.showwarning('Categorías', mensaje, parent=dialogo)
        boton(marco, 'Guardar categoría', guardar).grid(row=2, column=1, sticky='e', pady=12)

    # --- Reservas ---
    def armar_reservas(self):
        titulo_seccion(self.panel_reservas, 'Todas las reservas')
        acciones = ttk.Frame(self.panel_reservas)
        acciones.pack(fill='x', padx=12)
        boton(acciones, 'Cambiar estado', self.formulario_estado).pack(side='left')
        boton(acciones, 'Actualizar', self.actualizar_reservas).pack(side='left', padx=8)
        self.tabla_reservas = crear_tabla(self.panel_reservas,
            [('id_reserva', 'ID'), ('codigo_estudiante', 'Estudiante'), ('recurso', 'Recurso'),
             ('fecha_inicio', 'Inicio'), ('fecha_fin', 'Fin'), ('hora_inicio', 'Desde'),
             ('hora_fin', 'Hasta'), ('estado', 'Estado')], [65, 130, 250, 115, 115, 85, 85, 120])

    def actualizar_reservas(self):
        self.lista_reservas = consultar_todas_las_reservas()
        rellenar_tabla(self.tabla_reservas, self.lista_reservas,
                       ['id_reserva', 'codigo_estudiante', 'recurso', 'fecha_inicio',
                        'fecha_fin', 'hora_inicio', 'hora_fin', 'estado'])

    def formulario_estado(self):
        fila = seleccionado(self.tabla_reservas)
        if not fila:
            return
        dialogo, marco = crear_dialogo(self, 'Cambiar estado de reserva N.° ' + str(fila[0]))
        nuevo = campo_opciones(marco, 'Estado', ESTADOS_RESERVA, fila[7], 0)

        def guardar():
            bien, mensaje = actualizar_estado_reserva(int(fila[0]), nuevo.get())
            if bien:
                dialogo.destroy()
                self.actualizar_reservas()
                messagebox.showinfo('Reserva', mensaje)
            else:
                messagebox.showwarning('Reserva', mensaje, parent=dialogo)
        boton(marco, 'Guardar estado', guardar).grid(row=1, column=1, sticky='e', pady=12)

    # --- Horarios ---
    def armar_configuracion(self):
        titulo_seccion(self.panel_config, 'Horarios y duraciones')
        config = obtener_configuracion()
        marco = ttk.Frame(self.panel_config, padding=18)
        marco.pack(anchor='nw')
        self.apertura = campo_texto(marco, 'Hora de apertura (HH:MM)', config['hora_apertura'], 0)
        self.cierre = campo_texto(marco, 'Hora de cierre (HH:MM)', config['hora_cierre'], 1)
        self.duraciones = campo_texto(marco, 'Duraciones (horas, separadas por comas)',
                                     config['duraciones_permitidas'], 2)
        self.dias = campo_texto(marco, 'Préstamo de libros (días)',
                                config['duracion_prestamo_libros_dias'], 3)

        def guardar():
            bien, mensaje = actualizar_configuracion(self.apertura.get().strip(), self.cierre.get().strip(),
                                                      self.duraciones.get().strip(), self.dias.get().strip())
            if bien:
                messagebox.showinfo('Configuración', mensaje)
            else:
                messagebox.showwarning('Configuración', mensaje)
        boton(marco, 'Guardar configuración', guardar).grid(row=4, column=1, sticky='e', pady=14)
        ttk.Label(self.panel_config, text='Los cambios se aplican a nuevas reservas. No alteran las reservas existentes.',
                  foreground='#51687E').pack(anchor='w', padx=20)

    # --- Excel ---
    def armar_excel(self):
        titulo_seccion(self.panel_excel, 'Reporte administrativo')
        ttk.Label(self.panel_excel, text='Exporta tres hojas: Reservas, Inventario y Estudiantes.',
                  font=('Segoe UI', 11)).pack(anchor='w', padx=20, pady=8)
        ttk.Label(self.panel_excel, text='No incluye contraseñas ni hashes.', foreground='#51687E').pack(anchor='w', padx=20)
        boton(self.panel_excel, 'Exportar Excel (.xlsx)', self.exportar_excel).pack(anchor='w', padx=20, pady=25)

    def exportar_excel(self):
        ruta = filedialog.asksaveasfilename(parent=self, defaultextension='.xlsx',
            filetypes=[('Libro de Excel', '*.xlsx')], initialfile='Reporte_ReservaUPN.xlsx')
        if not ruta:
            return
        try:
            from reportes import exportar_reporte_completo
            bien, mensaje = exportar_reporte_completo(ruta)
            if bien:
                messagebox.showinfo('Reporte Excel', mensaje)
            else:
                messagebox.showerror('Reporte Excel', mensaje)
        except ImportError:
            messagebox.showerror('Falta una librería', 'Instala OpenPyXL con: python -m pip install openpyxl')

    # --- Administradores ---
    def armar_admins(self):
        titulo_seccion(self.panel_admins, 'Administradores del sistema')
        acciones = ttk.Frame(self.panel_admins)
        acciones.pack(fill='x', padx=12)
        boton(acciones, 'Nuevo administrador', lambda: self.formulario_admin()).pack(side='left', padx=(0, 8))
        boton(acciones, 'Editar seleccionado', self.editar_admin).pack(side='left', padx=(0, 8))
        boton(acciones, 'Eliminar seleccionado', self.eliminar_admin_seleccionado).pack(side='left', padx=(0, 8))
        boton(acciones, 'Hacer principal', self.hacer_principal).pack(side='left', padx=(0, 8))
        boton(acciones, 'Actualizar', self.actualizar_admins).pack(side='left')
        self.tabla_admins = crear_tabla(self.panel_admins,
            [('id_administrador', 'ID'), ('usuario', 'Usuario'), ('nombres', 'Nombres'),
             ('apellidos', 'Apellidos'), ('correo', 'Correo'), ('estado', 'Estado'), ('rol', 'Rol')],
            [55, 130, 160, 160, 240, 90, 160])
        if self.es_principal:
            texto = 'Eres el administrador principal: puedes crear, editar, eliminar y pasar tu rol a otro administrador.'
        else:
            texto = 'Solo el administrador principal puede crear o eliminar administradores. Tú puedes editar tus datos.'
        ttk.Label(self.panel_admins, text=texto, foreground='#51687E').pack(anchor='w', padx=12, pady=6)

    def actualizar_admins(self):
        self.lista_admins = listar_administradores()
        for admin in self.lista_admins:
            admin['rol'] = 'Principal' if admin['es_principal'] == 1 else 'Administrador'
        rellenar_tabla(self.tabla_admins, self.lista_admins,
                       ['id_administrador', 'usuario', 'nombres', 'apellidos', 'correo', 'estado', 'rol'])

    def editar_admin(self):
        fila = seleccionado(self.tabla_admins)
        if fila:
            datos = next((a for a in self.lista_admins if str(a['id_administrador']) == str(fila[0])), None)
            if datos:
                self.formulario_admin(datos)

    def eliminar_admin_seleccionado(self):
        fila = seleccionado(self.tabla_admins)
        if not fila:
            return
        if messagebox.askyesno('Confirmar eliminación',
                               '¿Seguro que quieres eliminar al administrador «' + str(fila[1]) + '»?\n'
                               'Esta acción no se puede deshacer.'):
            bien, mensaje = eliminar_administrador(self.administrador['id_administrador'], int(fila[0]))
            if bien:
                messagebox.showinfo('Administradores', mensaje)
                if int(fila[0]) == self.administrador['id_administrador']:
                    self.cerrar_sesion()          # eliminó su propia cuenta
                else:
                    self.actualizar_admins()
            else:
                messagebox.showwarning('Administradores', mensaje)

    def hacer_principal(self):
        fila = seleccionado(self.tabla_admins)
        if not fila:
            return
        if messagebox.askyesno('Confirmar', '¿Pasar el rol de administrador principal a «' + str(fila[1]) + '»?\n'
                               'Tú pasarás a ser administrador común y se cerrará tu sesión.'):
            bien, mensaje = transferir_principal(self.administrador['id_administrador'], int(fila[0]))
            if bien:
                messagebox.showinfo('Administradores', mensaje + '\nVuelve a iniciar sesión.')
                self.cerrar_sesion()
            else:
                messagebox.showwarning('Administradores', mensaje)

    def formulario_admin(self, datos=None):
        editar = datos is not None
        dialogo, marco = crear_dialogo(self, 'Editar administrador' if editar else 'Nuevo administrador')
        usuario = campo_texto(marco, 'Usuario', (datos or {}).get('usuario', ''), 0)
        if editar:
            usuario.configure(state='disabled')
        nombres = campo_texto(marco, 'Nombres', (datos or {}).get('nombres', ''), 1)
        apellidos = campo_texto(marco, 'Apellidos', (datos or {}).get('apellidos', ''), 2)
        correo = campo_texto(marco, 'Correo', (datos or {}).get('correo', ''), 3)
        telefono = campo_texto(marco, 'Teléfono', (datos or {}).get('telefono', ''), 4)
        estado = campo_opciones(marco, 'Estado', ESTADOS_ADMIN, (datos or {}).get('estado', 'Activo'), 5)
        contrasena = campo_texto(marco, 'Contraseña (8+)' if not editar else 'Nueva contraseña (8+)', '', 6, secreto=True)
        if editar:
            ttk.Label(marco, text='Deja la contraseña vacía para conservar la actual.',
                      foreground='#51687E').grid(row=7, column=0, columnspan=2, pady=7)

        def guardar():
            if editar:
                bien, mensaje = modificar_administrador(
                    self.administrador['id_administrador'], datos['id_administrador'], nombres.get(),
                    apellidos.get(), correo.get(), telefono.get(), estado.get(), contrasena.get())
            else:
                bien, mensaje = crear_administrador(
                    self.administrador['id_administrador'], usuario.get(), nombres.get(), apellidos.get(),
                    correo.get(), telefono.get(), contrasena.get())
            if bien:
                dialogo.destroy()
                self.actualizar_admins()
                messagebox.showinfo('Administradores', mensaje)
            else:
                messagebox.showwarning('Revisar datos', mensaje, parent=dialogo)
        boton(marco, 'Guardar administrador', guardar).grid(row=8, column=1, sticky='e', pady=12)
