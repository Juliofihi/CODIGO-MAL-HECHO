"""Ventanas de estudiantes: datos, catálogo, crear y cancelar reservas."""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date, timedelta, datetime
from interfaz_util import encabezado, titulo_seccion, crear_tabla, rellenar_tabla, seleccionado, boton
from recursos import listar_recursos
from estudiantes import obtener_estudiante
from reservas import crear_reserva, consultar_reservas_estudiante, cancelar_reserva
from database import obtener_configuracion


class PanelEstudiante(ttk.Frame):
    def __init__(self, padre, estudiante, cerrar_sesion):
        super().__init__(padre)
        self.estudiante = estudiante
        encabezado(self, 'ReservaUPN', 'Panel del estudiante: ' + estudiante['nombres'], cerrar_sesion)
        pestañas = ttk.Notebook(self)
        pestañas.pack(fill='both', expand=True, padx=14, pady=14)
        self.datos = ttk.Frame(pestañas)
        self.catalogo = ttk.Frame(pestañas)
        self.pedir = ttk.Frame(pestañas)
        self.mis_reservas = ttk.Frame(pestañas)
        for marco, nombre in ((self.datos, 'Mis datos'), (self.catalogo, 'Recursos'),
                              (self.pedir, 'Hacer reserva'), (self.mis_reservas, 'Mis reservas')):
            pestañas.add(marco, text=nombre)
        self.armar_datos()
        self.armar_catalogo()
        self.armar_formulario()
        self.armar_reservas()
        self.actualizar_catalogo()
        self.actualizar_reservas()

    def armar_datos(self):
        titulo_seccion(self.datos, 'Información registrada por la universidad')
        estudiante = obtener_estudiante(self.estudiante['codigo_estudiante'])
        for etiqueta, valor in (
            ('Código universitario', estudiante['codigo_estudiante']),
            ('Nombres y apellidos', estudiante['nombres'] + ' ' + estudiante['apellidos']),
            ('Correo', estudiante['correo']),
            ('Teléfono', estudiante['telefono'] or 'No registrado'),
            ('Estado', estudiante['estado']),
        ):
            ttk.Label(self.datos, text=f'{etiqueta}:  {valor}', font=('Segoe UI', 11)).pack(anchor='w', padx=22, pady=8)
        ttk.Label(self.datos, text='Los datos personales son administrados únicamente desde el panel administrativo.',
                  foreground='#51687E').pack(anchor='w', padx=22, pady=16)

    def armar_catalogo(self):
        titulo_seccion(self.catalogo, 'Inventario para consultar')
        opciones = ttk.Frame(self.catalogo)
        opciones.pack(fill='x', padx=12)
        boton(opciones, 'Actualizar recursos', self.actualizar_catalogo).pack(side='left')
        ttk.Label(opciones, text='Los recursos en mantenimiento o inactivos no se pueden reservar.').pack(side='left', padx=15)
        self.tabla_recursos = crear_tabla(self.catalogo,
            [('codigo_inventario', 'Código'), ('nombre', 'Nombre'), ('nombre_categoria', 'Categoría'),
             ('ubicacion', 'Ubicación'), ('estado', 'Estado')], [120, 250, 130, 220, 120])
        self.tabla_recursos.bind('<Double-1>', self.copiar_recurso)

    def copiar_recurso(self, evento=None):
        fila = seleccionado(self.tabla_recursos)
        if fila:
            codigo = fila[0]
            for opcion, codigo_real in self.codigos.items():
                if codigo == codigo_real:
                    self.combo_recurso.set(opcion)
                    self.cambio_recurso()
                    break

    def actualizar_catalogo(self):
        self.recursos = listar_recursos()
        rellenar_tabla(self.tabla_recursos, self.recursos,
                       ['codigo_inventario', 'nombre', 'nombre_categoria', 'ubicacion', 'estado'])
        self.codigos = {f"{r['codigo_inventario']} | {r['nombre']}": r['codigo_inventario'] for r in self.recursos if r['estado'] == 'Disponible'}
        self.combo_recurso['values'] = list(self.codigos)
        if self.codigos and self.combo_recurso.get() not in self.codigos:
            self.combo_recurso.current(0)
        self.cambio_recurso()

    def armar_formulario(self):
        titulo_seccion(self.pedir, 'Crear una reserva')
        marco = ttk.Frame(self.pedir, padding=20)
        marco.pack(anchor='nw')
        ttk.Label(marco, text='Recurso').grid(row=0, column=0, sticky='w', pady=9)
        self.combo_recurso = ttk.Combobox(marco, state='readonly', width=48)
        self.combo_recurso.grid(row=0, column=1, pady=9, padx=10)
        self.combo_recurso.bind('<<ComboboxSelected>>', lambda _ev: self.cambio_recurso())
        ttk.Label(marco, text='Fecha (AAAA-MM-DD)').grid(row=1, column=0, sticky='w', pady=9)
        self.entrada_fecha = ttk.Entry(marco, width=24)
        self.entrada_fecha.insert(0, (date.today() + timedelta(days=1)).isoformat())
        self.entrada_fecha.grid(row=1, column=1, sticky='w', padx=10)
        config = obtener_configuracion()
        ttk.Label(marco, text='Hora inicio').grid(row=2, column=0, sticky='w', pady=9)
        self.hora = ttk.Combobox(marco, width=21, state='normal')
        horas = []
        for hora in range(0, 24):
            for minuto in (0, 30):
                horas.append(f'{hora:02d}:{minuto:02d}')
        self.hora['values'] = horas
        self.hora.set(config['hora_apertura'])
        self.hora.grid(row=2, column=1, sticky='w', padx=10)
        ttk.Label(marco, text='Duración (horas)').grid(row=3, column=0, sticky='w', pady=9)
        duraciones = config['duraciones_permitidas'].split(',')
        self.duracion = ttk.Combobox(marco, values=duraciones, state='readonly', width=21)
        self.duracion.set(duraciones[0])
        self.duracion.grid(row=3, column=1, sticky='w', padx=10)
        self.ayuda = ttk.Label(marco, text='Elige un recurso para conocer el tipo de préstamo.', foreground='#51687E')
        self.ayuda.grid(row=4, column=0, columnspan=2, sticky='w', pady=12)
        boton(marco, 'Confirmar reserva', self.guardar_reserva).grid(row=5, column=1, sticky='w', pady=12)
        ttk.Label(self.pedir, text='Una reserva pendiente también bloquea el horario para otras personas.',
                  foreground='#51687E').pack(anchor='w', padx=20)

    def cambio_recurso(self):
        codigo = self.codigos.get(self.combo_recurso.get()) if hasattr(self, 'codigos') else None
        elegido = next((r for r in getattr(self, 'recursos', []) if r['codigo_inventario'] == codigo), None)
        config = obtener_configuracion()
        libro = elegido and str(elegido['id_categoria']) == config.get('id_categoria_libros')
        self.hora.configure(state='disabled' if libro else 'normal')
        self.duracion.configure(state='disabled' if libro else 'readonly')
        if libro:
            self.ayuda.configure(text='Préstamo de libro: ' + config['duracion_prestamo_libros_dias'] +
                                 ' días. No hace falta ingresar horario.')
        else:
            self.ayuda.configure(text='Horario de atención: ' + config['hora_apertura'] +
                                 ' a ' + config['hora_cierre'] + '.')
            self.duracion['values'] = config['duraciones_permitidas'].split(',')

    def guardar_reserva(self):
        codigo = self.codigos.get(self.combo_recurso.get())
        if not codigo:
            messagebox.showwarning('Falta recurso', 'Selecciona un recurso disponible.')
            return
        bien, mensaje = crear_reserva(self.estudiante['codigo_estudiante'], codigo,
                                      self.entrada_fecha.get().strip(),
                                      self.hora.get().strip(), self.duracion.get())
        if bien:
            messagebox.showinfo('Reserva', mensaje)
            self.actualizar_reservas()
        else:
            messagebox.showwarning('No se pudo reservar', mensaje)

    def armar_reservas(self):
        titulo_seccion(self.mis_reservas, 'Historial de mis reservas')
        opciones = ttk.Frame(self.mis_reservas)
        opciones.pack(fill='x', padx=12)
        boton(opciones, 'Actualizar', self.actualizar_reservas).pack(side='left')
        boton(opciones, 'Cancelar seleccionada', self.cancelar_seleccionada).pack(side='left', padx=10)
        self.tabla_reservas = crear_tabla(self.mis_reservas,
            [('id_reserva', 'N.°'), ('recurso', 'Recurso'), ('fecha_inicio', 'Inicio'), ('fecha_fin', 'Fin'),
             ('hora_inicio', 'Hora inicio'), ('hora_fin', 'Hora fin'), ('estado', 'Estado')],
             [65, 240, 120, 120, 105, 105, 130])

    def actualizar_reservas(self):
        datos = consultar_reservas_estudiante(self.estudiante['codigo_estudiante'])
        rellenar_tabla(self.tabla_reservas, datos,
                       ['id_reserva', 'recurso', 'fecha_inicio', 'fecha_fin', 'hora_inicio', 'hora_fin', 'estado'])

    def cancelar_seleccionada(self):
        fila = seleccionado(self.tabla_reservas)
        if fila and messagebox.askyesno('Confirmar', '¿Quieres cancelar la reserva N.° ' + str(fila[0]) + '?'):
            bien, mensaje = cancelar_reserva(int(fila[0]), self.estudiante['codigo_estudiante'])
            if bien:
                messagebox.showinfo('Resultado', mensaje)
                self.actualizar_reservas()
            else:
                messagebox.showwarning('No se pudo cancelar', mensaje)
